(function (React, ReactDOM, uuid, reactRouterDom) {
'use strict';

var React__default = 'default' in React ? React['default'] : React;

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

var objectWithoutPropertiesLoose = _objectWithoutPropertiesLoose;

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = objectWithoutPropertiesLoose(source, excluded);
  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

var objectWithoutProperties = _objectWithoutProperties;

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function createCommonjsModule(fn, basedir, module) {
	return module = {
	  path: basedir,
	  exports: {},
	  require: function (path, base) {
      return commonjsRequire(path, (base === undefined || base === null) ? module.path : base);
    }
	}, fn(module, module.exports), module.exports;
}

function commonjsRequire () {
	throw new Error('Dynamic requires are not currently supported by @rollup/plugin-commonjs');
}

var _typeof_1 = createCommonjsModule(function (module) {
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;
});

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

var defineProperty = _defineProperty;

/**
 * This file automatically generated from `pre-publish.js`.
 * Do not manually edit.
 */

var voidElements = {
  "area": true,
  "base": true,
  "br": true,
  "col": true,
  "embed": true,
  "hr": true,
  "img": true,
  "input": true,
  "keygen": true,
  "link": true,
  "menuitem": true,
  "meta": true,
  "param": true,
  "source": true,
  "track": true,
  "wbr": true
};

var attrRE = /([\w-]+)|=|(['"])([.\s\S]*?)\2/g;


var parseTag = function (tag) {
    var i = 0;
    var key;
    var expectingValueAfterEquals = true;
    var res = {
        type: 'tag',
        name: '',
        voidElement: false,
        attrs: {},
        children: []
    };

    tag.replace(attrRE, function (match) {
        if (match === '=') {
            expectingValueAfterEquals = true;
            i++;
            return;
        }

        if (!expectingValueAfterEquals) {
            if (key) {
                res.attrs[key] = key; // boolean attribute
            }
            key=match;
        } else {
            if (i === 0) {
                if (voidElements[match] || tag.charAt(tag.length - 2) === '/') {
                    res.voidElement = true;
                }
                res.name = match;
            } else {
                res.attrs[key] = match.replace(/^['"]|['"]$/g, '');
                key=undefined;
            }
        }
        i++;
        expectingValueAfterEquals = false;
    });

    return res;
};

/*jshint -W030 */
var tagRE = /(?:<!--[\S\s]*?-->|<(?:"[^"]*"['"]*|'[^']*'['"]*|[^'">])+>)/g;

// re-used obj for quick lookups of components
var empty = Object.create ? Object.create(null) : {};
// common logic for pushing a child node onto a list
function pushTextNode(list, html, level, start, ignoreWhitespace) {
    // calculate correct end of the content slice in case there's
    // no tag after the text node.
    var end = html.indexOf('<', start);
    var content = html.slice(start, end === -1 ? undefined : end);
    // if a node is nothing but whitespace, collapse it as the spec states:
    // https://www.w3.org/TR/html4/struct/text.html#h-9.1
    if (/^\s*$/.test(content)) {
        content = ' ';
    }
    // don't add whitespace-only text nodes if they would be trailing text nodes
    // or if they would be leading whitespace-only text nodes:
    //  * end > -1 indicates this is not a trailing text node
    //  * leading node is when level is -1 and list has length 0
    if ((!ignoreWhitespace && end > -1 && level + list.length >= 0) || content !== ' ') {
        list.push({
            type: 'text',
            content: content
        });
    }
}

var parse = function parse(html, options) {
    options || (options = {});
    options.components || (options.components = empty);
    var result = [];
    var current;
    var level = -1;
    var arr = [];
    var byTag = {};
    var inComponent = false;

    html.replace(tagRE, function (tag, index) {
        if (inComponent) {
            if (tag !== ('</' + current.name + '>')) {
                return;
            } else {
                inComponent = false;
            }
        }

        var isOpen = tag.charAt(1) !== '/';
        var isComment = tag.indexOf('<!--') === 0;
        var start = index + tag.length;
        var nextChar = html.charAt(start);
        var parent;

        if (isOpen && !isComment) {
            level++;

            current = parseTag(tag);
            if (current.type === 'tag' && options.components[current.name]) {
                current.type = 'component';
                inComponent = true;
            }

            if (!current.voidElement && !inComponent && nextChar && nextChar !== '<') {
                pushTextNode(current.children, html, level, start, options.ignoreWhitespace);
            }

            byTag[current.tagName] = current;

            // if we're at root, push new base node
            if (level === 0) {
                result.push(current);
            }

            parent = arr[level - 1];

            if (parent) {
                parent.children.push(current);
            }

            arr[level] = current;
        }

        if (isComment || !isOpen || current.voidElement) {
            if (!isComment) {
                level--;
            }
            if (!inComponent && nextChar !== '<' && nextChar) {
                // trailing text node
                // if we're at the root, push a base text node. otherwise add as
                // a child to the current node.
                parent = level === -1 ? result : arr[level].children;
                pushTextNode(parent, html, level, start, options.ignoreWhitespace);
            }
        }
    });

    // If the "html" passed isn't actually html, add it as a text node.
    if (!result.length && html.length) {
        pushTextNode(result, html, 0, 0, options.ignoreWhitespace);
    }

    return result;
};

function attrString(attrs) {
    var buff = [];
    for (var key in attrs) {
        buff.push(key + '="' + attrs[key] + '"');
    }
    if (!buff.length) {
        return '';
    }
    return ' ' + buff.join(' ');
}

function stringify(buff, doc) {
    switch (doc.type) {
    case 'text':
        return buff + doc.content;
    case 'tag':
        buff += '<' + doc.name + (doc.attrs ? attrString(doc.attrs) : '') + (doc.voidElement ? '/>' : '>');
        if (doc.voidElement) {
            return buff;
        }
        return buff + doc.children.reduce(stringify, '') + '</' + doc.name + '>';
    }
}

var stringify_1 = function (doc) {
    return doc.reduce(function (token, rootEl) {
        return token + stringify('', rootEl);
    }, '');
};

var htmlParseStringify2 = {
    parse: parse,
    stringify: stringify_1
};

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

var classCallCheck = _classCallCheck;

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

var createClass = _createClass;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }
var defaultOptions = {
  bindI18n: 'languageChanged',
  bindI18nStore: '',
  transEmptyNodeValue: '',
  transSupportBasicHtmlNodes: true,
  transKeepBasicHtmlNodesFor: ['br', 'strong', 'i', 'p'],
  useSuspense: true
};
var i18nInstance;
var I18nContext = React__default.createContext();
function setDefaults() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  defaultOptions = _objectSpread(_objectSpread({}, defaultOptions), options);
}
function getDefaults() {
  return defaultOptions;
}
var ReportNamespaces = function () {
  function ReportNamespaces() {
    classCallCheck(this, ReportNamespaces);

    this.usedNamespaces = {};
  }

  createClass(ReportNamespaces, [{
    key: "addUsedNamespaces",
    value: function addUsedNamespaces(namespaces) {
      var _this = this;

      namespaces.forEach(function (ns) {
        if (!_this.usedNamespaces[ns]) _this.usedNamespaces[ns] = true;
      });
    }
  }, {
    key: "getUsedNamespaces",
    value: function getUsedNamespaces() {
      return Object.keys(this.usedNamespaces);
    }
  }]);

  return ReportNamespaces;
}();
function setI18n(instance) {
  i18nInstance = instance;
}
function getI18n() {
  return i18nInstance;
}
var initReactI18next = {
  type: '3rdParty',
  init: function init(instance) {
    setDefaults(instance.options.react);
    setI18n(instance);
  }
};

function warn() {
  if (console && console.warn) {
    var _console;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    if (typeof args[0] === 'string') args[0] = "react-i18next:: ".concat(args[0]);

    (_console = console).warn.apply(_console, args);
  }
}
var alreadyWarned = {};
function warnOnce() {
  for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    args[_key2] = arguments[_key2];
  }

  if (typeof args[0] === 'string' && alreadyWarned[args[0]]) return;
  if (typeof args[0] === 'string') alreadyWarned[args[0]] = new Date();
  warn.apply(void 0, args);
}
function loadNamespaces(i18n, ns, cb) {
  i18n.loadNamespaces(ns, function () {
    if (i18n.isInitialized) {
      cb();
    } else {
      var initialized = function initialized() {
        setTimeout(function () {
          i18n.off('initialized', initialized);
        }, 0);
        cb();
      };

      i18n.on('initialized', initialized);
    }
  });
}
function hasLoadedNamespace(ns, i18n) {
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  if (!i18n.languages || !i18n.languages.length) {
    warnOnce('i18n.languages were undefined or empty', i18n.languages);
    return true;
  }

  var lng = i18n.languages[0];
  var fallbackLng = i18n.options ? i18n.options.fallbackLng : false;
  var lastLng = i18n.languages[i18n.languages.length - 1];
  if (lng.toLowerCase() === 'cimode') return true;

  var loadNotPending = function loadNotPending(l, n) {
    var loadState = i18n.services.backendConnector.state["".concat(l, "|").concat(n)];
    return loadState === -1 || loadState === 2;
  };

  if (options.bindI18n && options.bindI18n.indexOf('languageChanging') > -1 && i18n.services.backendConnector.backend && i18n.isLanguageChangingTo && !loadNotPending(i18n.isLanguageChangingTo, ns)) return false;
  if (i18n.hasResourceBundle(lng, ns)) return true;
  if (!i18n.services.backendConnector.backend) return true;
  if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
  return false;
}

function ownKeys$1(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread$1(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys$1(Object(source), true).forEach(function (key) { defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys$1(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function hasChildren(node, checkLength) {
  if (!node) return false;
  var base = node.props ? node.props.children : node.children;
  if (checkLength) return base.length > 0;
  return !!base;
}

function getChildren(node) {
  if (!node) return [];
  return node && node.children ? node.children : node.props && node.props.children;
}

function hasValidReactChildren(children) {
  if (Object.prototype.toString.call(children) !== '[object Array]') return false;
  return children.every(function (child) {
    return React__default.isValidElement(child);
  });
}

function getAsArray(data) {
  return Array.isArray(data) ? data : [data];
}

function mergeProps(source, target) {
  var newTarget = _objectSpread$1({}, target);

  newTarget.props = Object.assign(source.props, target.props);
  return newTarget;
}

function nodesToString(children, i18nOptions) {
  if (!children) return '';
  var stringNode = '';
  var childrenArray = getAsArray(children);
  var keepArray = i18nOptions.transKeepBasicHtmlNodesFor || [];
  childrenArray.forEach(function (child, childIndex) {
    if (typeof child === 'string') {
      stringNode += "".concat(child);
    } else if (React__default.isValidElement(child)) {
      var childPropsCount = Object.keys(child.props).length;
      var shouldKeepChild = keepArray.indexOf(child.type) > -1;
      var childChildren = child.props.children;

      if (!childChildren && shouldKeepChild && childPropsCount === 0) {
        stringNode += "<".concat(child.type, "/>");
      } else if (!childChildren && (!shouldKeepChild || childPropsCount !== 0)) {
        stringNode += "<".concat(childIndex, "></").concat(childIndex, ">");
      } else if (child.props.i18nIsDynamicList) {
        stringNode += "<".concat(childIndex, "></").concat(childIndex, ">");
      } else if (shouldKeepChild && childPropsCount === 1 && typeof childChildren === 'string') {
        stringNode += "<".concat(child.type, ">").concat(childChildren, "</").concat(child.type, ">");
      } else {
        var content = nodesToString(childChildren, i18nOptions);
        stringNode += "<".concat(childIndex, ">").concat(content, "</").concat(childIndex, ">");
      }
    } else if (_typeof_1(child) === 'object') {
      var format = child.format,
          clone = objectWithoutProperties(child, ["format"]);

      var keys = Object.keys(clone);

      if (keys.length === 1) {
        var value = format ? "".concat(keys[0], ", ").concat(format) : keys[0];
        stringNode += "{{".concat(value, "}}");
      } else {
        warn("react-i18next: the passed in object contained more than one variable - the object should look like {{ value, format }} where format is optional.", child);
      }
    } else {
      warn("Trans: the passed in value is invalid - seems you passed in a variable like {number} - please pass in variables for interpolation as full objects like {{number}}.", child);
    }
  });
  return stringNode;
}

function renderNodes(children, targetString, i18n, i18nOptions, combinedTOpts) {
  if (targetString === '') return [];
  var keepArray = i18nOptions.transKeepBasicHtmlNodesFor || [];
  var emptyChildrenButNeedsHandling = targetString && new RegExp(keepArray.join('|')).test(targetString);
  if (!children && !emptyChildrenButNeedsHandling) return [targetString];
  var data = {};

  function getData(childs) {
    var childrenArray = getAsArray(childs);
    childrenArray.forEach(function (child) {
      if (typeof child === 'string') return;
      if (hasChildren(child)) getData(getChildren(child));else if (_typeof_1(child) === 'object' && !React__default.isValidElement(child)) Object.assign(data, child);
    });
  }

  getData(children);
  var interpolatedString = i18n.services.interpolator.interpolate(targetString, _objectSpread$1(_objectSpread$1({}, data), combinedTOpts), i18n.language);
  var ast = htmlParseStringify2.parse("<0>".concat(interpolatedString, "</0>"));

  function renderInner(child, node, rootReactNode) {
    var childs = getChildren(child);
    var mappedChildren = mapAST(childs, node.children, rootReactNode);
    return hasValidReactChildren(childs) && mappedChildren.length === 0 ? childs : mappedChildren;
  }

  function pushTranslatedJSX(child, inner, mem, i) {
    if (child.dummy) child.children = inner;
    mem.push(React__default.cloneElement(child, _objectSpread$1(_objectSpread$1({}, child.props), {}, {
      key: i
    }), inner));
  }

  function mapAST(reactNode, astNode, rootReactNode) {
    var reactNodes = getAsArray(reactNode);
    var astNodes = getAsArray(astNode);
    return astNodes.reduce(function (mem, node, i) {
      var translationContent = node.children && node.children[0] && node.children[0].content;

      if (node.type === 'tag') {
        var tmp = reactNodes[parseInt(node.name, 10)];
        if (!tmp && rootReactNode.length === 1 && rootReactNode[0][node.name]) tmp = rootReactNode[0][node.name];
        if (!tmp) tmp = {};
        var child = Object.keys(node.attrs).length !== 0 ? mergeProps({
          props: node.attrs
        }, tmp) : tmp;
        var isElement = React__default.isValidElement(child);
        var isValidTranslationWithChildren = isElement && hasChildren(node, true) && !node.voidElement;
        var isEmptyTransWithHTML = emptyChildrenButNeedsHandling && _typeof_1(child) === 'object' && child.dummy && !isElement;
        var isKnownComponent = _typeof_1(children) === 'object' && children !== null && Object.hasOwnProperty.call(children, node.name);

        if (typeof child === 'string') {
          mem.push(child);
        } else if (hasChildren(child) || isValidTranslationWithChildren) {
            var inner = renderInner(child, node, rootReactNode);
            pushTranslatedJSX(child, inner, mem, i);
          } else if (isEmptyTransWithHTML) {
          var _inner = mapAST(reactNodes, node.children, rootReactNode);

          mem.push(React__default.cloneElement(child, _objectSpread$1(_objectSpread$1({}, child.props), {}, {
            key: i
          }), _inner));
        } else if (Number.isNaN(parseFloat(node.name))) {
          if (isKnownComponent) {
            var _inner2 = renderInner(child, node, rootReactNode);

            pushTranslatedJSX(child, _inner2, mem, i);
          } else if (i18nOptions.transSupportBasicHtmlNodes && keepArray.indexOf(node.name) > -1) {
            if (node.voidElement) {
              mem.push(React__default.createElement(node.name, {
                key: "".concat(node.name, "-").concat(i)
              }));
            } else {
              var _inner3 = mapAST(reactNodes, node.children, rootReactNode);

              mem.push(React__default.createElement(node.name, {
                key: "".concat(node.name, "-").concat(i)
              }, _inner3));
            }
          } else if (node.voidElement) {
            mem.push("<".concat(node.name, " />"));
          } else {
            var _inner4 = mapAST(reactNodes, node.children, rootReactNode);

            mem.push("<".concat(node.name, ">").concat(_inner4, "</").concat(node.name, ">"));
          }
        } else if (_typeof_1(child) === 'object' && !isElement) {
          var content = node.children[0] ? translationContent : null;
          if (content) mem.push(content);
        } else if (node.children.length === 1 && translationContent) {
          mem.push(React__default.cloneElement(child, _objectSpread$1(_objectSpread$1({}, child.props), {}, {
            key: i
          }), translationContent));
        } else {
          mem.push(React__default.cloneElement(child, _objectSpread$1(_objectSpread$1({}, child.props), {}, {
            key: i
          })));
        }
      } else if (node.type === 'text') {
        mem.push(node.content);
      }

      return mem;
    }, []);
  }

  var result = mapAST([{
    dummy: true,
    children: children
  }], ast, getAsArray(children || []));
  return getChildren(result[0]);
}

function Trans(_ref) {
  var children = _ref.children,
      count = _ref.count,
      parent = _ref.parent,
      i18nKey = _ref.i18nKey,
      tOptions = _ref.tOptions,
      values = _ref.values,
      defaults = _ref.defaults,
      components = _ref.components,
      ns = _ref.ns,
      i18nFromProps = _ref.i18n,
      tFromProps = _ref.t,
      additionalProps = objectWithoutProperties(_ref, ["children", "count", "parent", "i18nKey", "tOptions", "values", "defaults", "components", "ns", "i18n", "t"]);

  var _ref2 = React.useContext(I18nContext) || {},
      i18nFromContext = _ref2.i18n,
      defaultNSFromContext = _ref2.defaultNS;

  var i18n = i18nFromProps || i18nFromContext || getI18n();

  if (!i18n) {
    warnOnce('You will need to pass in an i18next instance by using i18nextReactModule');
    return children;
  }

  var t = tFromProps || i18n.t.bind(i18n) || function (k) {
    return k;
  };

  var reactI18nextOptions = _objectSpread$1(_objectSpread$1({}, getDefaults()), i18n.options && i18n.options.react);

  var namespaces = ns || t.ns || defaultNSFromContext || i18n.options && i18n.options.defaultNS;
  namespaces = typeof namespaces === 'string' ? [namespaces] : namespaces || ['translation'];
  var defaultValue = defaults || nodesToString(children, reactI18nextOptions) || reactI18nextOptions.transEmptyNodeValue || i18nKey;
  var hashTransKey = reactI18nextOptions.hashTransKey;
  var key = i18nKey || (hashTransKey ? hashTransKey(defaultValue) : defaultValue);
  var interpolationOverride = values ? {} : {
    interpolation: {
      prefix: '#$?',
      suffix: '?$#'
    }
  };

  var combinedTOpts = _objectSpread$1(_objectSpread$1(_objectSpread$1(_objectSpread$1({}, tOptions), {}, {
    count: count
  }, values), interpolationOverride), {}, {
    defaultValue: defaultValue,
    ns: namespaces
  });

  var translation = key ? t(key, combinedTOpts) : defaultValue;
  var content = renderNodes(components || children, translation, i18n, reactI18nextOptions, combinedTOpts);
  var useAsParent = parent !== undefined ? parent : reactI18nextOptions.defaultTransParent;
  return useAsParent ? React__default.createElement(useAsParent, additionalProps, content) : content;
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

var arrayWithHoles = _arrayWithHoles;

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

var iterableToArrayLimit = _iterableToArrayLimit;

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

var arrayLikeToArray = _arrayLikeToArray;

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

var unsupportedIterableToArray = _unsupportedIterableToArray;

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

var nonIterableRest = _nonIterableRest;

function _slicedToArray(arr, i) {
  return arrayWithHoles(arr) || iterableToArrayLimit(arr, i) || unsupportedIterableToArray(arr, i) || nonIterableRest();
}

var slicedToArray = _slicedToArray;

function ownKeys$2(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread$2(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys$2(Object(source), true).forEach(function (key) { defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys$2(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }
function useTranslation(ns) {
  var props = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var i18nFromProps = props.i18n;

  var _ref = React.useContext(I18nContext) || {},
      i18nFromContext = _ref.i18n,
      defaultNSFromContext = _ref.defaultNS;

  var i18n = i18nFromProps || i18nFromContext || getI18n();
  if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new ReportNamespaces();

  if (!i18n) {
    warnOnce('You will need to pass in an i18next instance by using initReactI18next');

    var notReadyT = function notReadyT(k) {
      return Array.isArray(k) ? k[k.length - 1] : k;
    };

    var retNotReady = [notReadyT, {}, false];
    retNotReady.t = notReadyT;
    retNotReady.i18n = {};
    retNotReady.ready = false;
    return retNotReady;
  }

  var i18nOptions = _objectSpread$2(_objectSpread$2(_objectSpread$2({}, getDefaults()), i18n.options.react), props);

  var useSuspense = i18nOptions.useSuspense;
  var namespaces = ns || defaultNSFromContext || i18n.options && i18n.options.defaultNS;
  namespaces = typeof namespaces === 'string' ? [namespaces] : namespaces || ['translation'];
  if (i18n.reportNamespaces.addUsedNamespaces) i18n.reportNamespaces.addUsedNamespaces(namespaces);
  var ready = (i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every(function (n) {
    return hasLoadedNamespace(n, i18n, i18nOptions);
  });

  function getT() {
    return {
      t: i18n.getFixedT(null, i18nOptions.nsMode === 'fallback' ? namespaces : namespaces[0])
    };
  }

  var _useState = React.useState(getT()),
      _useState2 = slicedToArray(_useState, 2),
      t = _useState2[0],
      setT = _useState2[1];

  var isMounted = React.useRef(true);
  React.useEffect(function () {
    var bindI18n = i18nOptions.bindI18n,
        bindI18nStore = i18nOptions.bindI18nStore;
    isMounted.current = true;

    if (!ready && !useSuspense) {
      loadNamespaces(i18n, namespaces, function () {
        if (isMounted.current) setT(getT());
      });
    }

    function boundReset() {
      if (isMounted.current) setT(getT());
    }

    if (bindI18n && i18n) i18n.on(bindI18n, boundReset);
    if (bindI18nStore && i18n) i18n.store.on(bindI18nStore, boundReset);
    return function () {
      isMounted.current = false;
      if (bindI18n && i18n) bindI18n.split(' ').forEach(function (e) {
        return i18n.off(e, boundReset);
      });
      if (bindI18nStore && i18n) bindI18nStore.split(' ').forEach(function (e) {
        return i18n.store.off(e, boundReset);
      });
    };
  }, [namespaces.join()]);
  var ret = [t.t, i18n, ready];
  ret.t = t.t;
  ret.i18n = i18n;
  ret.ready = ready;
  if (ready) return ret;
  if (!ready && !useSuspense) return ret;
  throw new Promise(function (resolve) {
    loadNamespaces(i18n, namespaces, function () {
      if (isMounted.current) setT(getT());
      resolve();
    });
  });
}

// hacky stuff
async function getStoredLanguage() {
    return "de";
}

const getStoredOrPhoneLanguageCode = async function (t) {
    return "de";
};

const storeLanguage = async function (languageCode) {
    return;
};

class PpQObject {

    // Answer the object to be stored in the answer json document.
    // By default this is the questions value, but it may be an id.
    answer() {
        return this.value();
    }

    toJSON() {
        let jsonObject = {};
        Object.assign(jsonObject, this);
        jsonObject.__class__ = this.constructor.name;
        return jsonObject;
    }

    postJSONLoad() {
        // Nothing to do
    }

    static fromJSON(jsonObject) {
        let newObject = new this();
        Object.assign(newObject, jsonObject);
        delete newObject['__class__'];
        return newObject;
    }

}

//
// ActivationConditions are used to determine whether the current
// question should be presented to the user.
//
// Typical criteria include:
// - Do or don't present based on the value chosen in a 
//   previous question.
// - Do or don't present based on the language
//
// Instance variables:
//
// _question: the current question (which will or won't be presented)
//

class PpActivationCondition extends PpQObject {
    constructor() {
        super();
        this._question = null;
    }

    get question() {
        return this._question;
    }

    set question(question) {
        this._question = question;
    }

    isActive() {
        throw Error('subclass responsibility');
    }

    toJSON() {
        let jsonObject = super.toJSON();
        if (this._question != null) {
            jsonObject._question = this._question.id;
        }
        return jsonObject;
    }

    postJSONLoad(questionnaire) {
        super.postJSONLoad();
        if (this._question != null) {
            // The JSON object just stores the question id.
            // Retrieve the real object.
            this._question = questionnaire.questionId(this._question);
        }
    }
}

// //module.exports = PpActivationCondition;

//
// PpDependOnAnotherQuestion is an abstract class that is activated
// based on the response chosen in another question.
// Subclasses exist for each type of selector question.
//
// Instance variables:
//
// - _dependent_question: The question whose value will determine
//   whether to display the current question
//

class PpDependOnAnotherQuestion extends PpActivationCondition {
    constructor(dependent_question) {
        super();
        this._dependent_question = dependent_question;
    }

    get dependent_question() {
        return this._dependent_question;
    }

    set dependent_question(question) {
        this._dependent_question = question;
    }

    toJSON() {
        let jsonObject = super.toJSON();
        jsonObject._dependent_question = this._dependent_question.id;
        return jsonObject;
    }

    postJSONLoad(questionnaire) {
        super.postJSONLoad(questionnaire);
        // The JSON object just stores the question id.
        // Retrieve the real object.
        this._dependent_question = questionnaire.questionId(this._dependent_question);
    }
}

class PpDependOnSingleChoice extends PpDependOnAnotherQuestion {
    constructor(dependent_question, choice) {
        super(dependent_question);
        this._choice = choice;
    }

    choice() {
        return this._choice;
    }

    setChoice(choice) {
        this._choice = choice;
        return this;
    }

    isActive() {
        return this._choice.isSelected();
    }

    toJSON() {
        // Save the index of the choice and reconstruct on deseralisation
        let choice = this._dependent_question.choices().indexOf(this._choice);
        let jsonObject = super.toJSON();
        jsonObject._choice = choice;
        return jsonObject;
    }

    postJSONLoad(questionnaire) {
        super.postJSONLoad(questionnaire);
        let choice = this._dependent_question.choices()[this._choice];
        this._choice = choice;
    }
}

function assert(assertion) {
    if (!assertion) {
        throw "Everything is burning. What have you done?";
    }
}

function localizedDate(date, locale) {
  if (!date) {
    return null;
  }

  if (locale === 'en') {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return (
      date.getDate() + ' ' + months[date.getMonth()] + ' ' + date.getFullYear()
    );
  }

  if (locale === 'de') {
    const months = [
      'Januar',
      'Februar',
      'März',
      'April',
      'Mai',
      'Juni',
      'Juli',
      'August',
      'September',
      'Oktober',
      'November',
      'Dezember',
    ];
    return (
      date.getDate() + ' ' + months[date.getMonth()] + ' ' + date.getFullYear()
    );
  }

  return date.toDateString();
}

//import { timingSafeEqual } from 'crypto';

//
// PpQuestionnaire
//
// Instance Variables:
//
// - _title: The title of the questionnaire
// - _description: Text introducing the questionnaire
// - _published_date: The date the questionnaire is scheduled to be made
//   available
// - _question_language: is the language used by PpDependOnLanguage
//   to activate / deactivate questions.
//   The format is <languageCode>[_<countryCode>],
//   e.g. "en" or "en_AU".  String encoding may be present and is
//   ignored, e.g. "en_AU.UTF-8".
//   This is currently the same as the display language (and is set
//   when the display language is set), but notionally could be separate
//   at some point in the future.
// - _available_translations is a simple object containing
//   the translations that can be loaded for the questionnaire.
//   e.g. { english: 'en', german: 'de' }
//   will look for en.js in the questionnaire directory.
// - _last_saved_time - the time at which the answers document was last
//   retrieved.
// - _last_submitted_time - the time at which the answers were last
//   submitted to the server.
// - _submission_deadline - is a Date object representing the submission
//   deadline date.
// - _encryption_public_key - a public key to encrypt answers before submitting them
//

class PpQuestionnaire extends PpQObject {
  constructor() {
    super();
    this._id = uuid.v1();
    this._date_generated = new Date();
    this._title = null;
    this._description = null;
    this._published_date = null;
    this._author = null;
    this._legal = null;
    this._questions = [];
    this._question_language = null;
    this._available_translations = null;
    this._last_saved_time = null;
    this._last_submitted_time = null;
    this._submission_deadline = null;
    this._encryption_public_key = null;
    this._result = null;
    this._schema = null;
  }

  get id() {
    return this._id;
  }

  set id(newId) {
    this._id = newId;
  }

  activeQuestions() {
    return this._questions.filter(item => item.isActive());
  }

  questions() {
    return this._questions;
  }

  firstActiveQuestion() {
    return this.activeQuestions()[0];
  }

  get question_language() {
    return this._question_language;
  }

  set question_language(language) {
    this._question_language = language;
  }

  get available_translations() {
    return this._available_translations;
  }

  set available_translations(translations) {
    this._available_translations = translations;
  }

  get last_saved_time() {
    return this._last_saved_time;
  }

  get last_submitted_time() {
    return this._last_submitted_time;
  }

  submittedTimeString(locale) {
    return localizedDate(new Date(this._last_submitted_time), locale);
  }

  get submission_deadline() {
    return this._submission_deadline;
  }

  set submission_deadline(date) {
    this._submission_deadline = date;
  }

  submissionDeadlineString(locale) {
    return localizedDate(this._submission_deadline, locale);
  }

  get encryption_public_key() {
    return this._encryption_public_key;
  }

  set encryption_public_key(key) {
    this._encryption_public_key = key;
  }

  get result() {
    return this._result;
  }

  set result(newResult) {
    this._result = newResult;
  }

  get title() {
    return this._title;
  }

  set title(newTitle) {
    this._title = newTitle;
  }

  get description() {
    return this._description;
  }

  set description(description) {
    this._description = description;
  }

  get published_date() {
    return this._published_date;
  }

  set published_date(published_date) {
    this._published_date = published_date;
  }

  publishedDateString(locale) {
    return localizedDate(this._published_date, locale);
  }

  get author() {
    return this._author;
  }

  set author(author) {
    this._author = author;
  }

  get legal() {
    return this._legal;
  }

  set legal(legal) {
    this._legal = legal;
  }

  get schema() {
    return this._schema;
  }

  set schema(schema) {
    this._schema = schema;
  }

  // Answer the active question prior to the supplied question.
  // If the supplied question is the first question, answer null.
  // If the question can't be found, throw an error.
  activeQuestionBefore(a_question) {
    let index = a_question.index;

    do {
      index = index - 1;
    } while (index >= 0 && !this._questions[index].isActive());

    if (index < 0) {
      return null;
    }
    return this._questions[index];
  }

  isFirstQuestion(a_question) {
    return this.firstActiveQuestion() === a_question;
  }

  isLastQuestion(a_question) {
    return (
      this.activeQuestions()[this.activeQuestions().length - 1] === a_question
    );
  }

  // Answer the active question after the supplied question.
  // If the supplied question is the last question, answer null.
  // If the question can't be found, throw an error.
  activeQuestionAfter(a_question) {
    let index = a_question.index;

    do {
      index = index + 1;
    } while (
      index < this._questions.length &&
      !this._questions[index].isActive()
    );

    if (index > this._questions.length) {
      return null;
    }
    return this._questions[index];
  }

  // Answer the question with the supplied id
  questionId(qId) {
    return this._questions.find(question => question.id === qId);
  }

  addQuestion(question) {
    this._questions[this._questions.length] = question;
    question.questionnaire = this;
    this.reindex();
    return this;
  }

  // Return the array of all answered questions
  answeredQuestions() {
    return this._questions.filter(question => question.isAnswered());
  }

  // Return the first active, unanswered question,
  // or null if all have been answered or aren't active.
  firstUnansweredQuestion() {
    let firstUnanswered = this._questions.find(
      question => !question.isAnswered() && question.isActive(),
    );
    return firstUnanswered || null;
  }

  // Return the last answered question
  // Simplistic implementation for now
  lastAnsweredQuestion() {
    let answeredQuestions = this.answeredQuestions();
    if (answeredQuestions.length === 0) {
      return null;
    }
    return answeredQuestions[answeredQuestions.length - 1].index;
  }

  hasAnsweredQuestions() {
    return (
      this.answeredQuestions() !== null && this.answeredQuestions().length > 0
    );
  }

  updateSavedTime() {
    this._last_saved_time = new Date();
  }

  updateSubmittedTime() {
    this._last_submitted_time = new Date();
  }

  isSubmitted() {
    return this._last_submitted_time !== null;
  }

  isActive() {
    return !this.isExpired() && !this.isSubmitted();
  }

  isExpired() {
    const currentDate = new Date();
    return this._submission_deadline < currentDate;
  }

  hasResult() {
    return this._result !== null;
  }

  // Set the index number of all the receiver's questions
  reindex() {
    this._questions.forEach((question, index) => {
      question.index = index;
    });
    return this;
  }

  // Answer an object containing just the user's answers.
  // Note that this call doesn't update the last saved time.
  // Normally answerJSON() will be used to retrieve the document for
  // saving.
  basicAnswerJSON() {
    let jsonObject = {};
    jsonObject.schema = this.schema;
    jsonObject.questionnaireId = this.id;
    jsonObject.answers = this.questions().map(question => {
      return {questionId: question.id, answer: question.answer()};
    });
    // The langauge is set each time the application starts and when the user
    // chooses a language, thus the language included with the answers is the
    // one at the time the answers are submitted.  While answering questions a
    // different language may have been used.
    jsonObject.language = this.question_language;
    return jsonObject;
  }

  answerJSON() {
    this.updateSavedTime();
    let jsonObject = this.basicAnswerJSON();
    jsonObject._last_saved_time = this.last_saved_time;
    jsonObject._last_submitted_time = this.last_submitted_time;
    jsonObject._question_language = this._question_language;
    return jsonObject;
  }

  answerJSONForSubmit() {
    let jsonObject = this.basicAnswerJSON();
    return jsonObject;
  }

  // Update the receiver with the answers from the supplied object
  loadAnswers(jsonObject) {
    assert(jsonObject.questionnaireId === this.id);
    jsonObject.answers.forEach((answer, index) => {
      let question = this.questions()[index];
      assert(question.id === answer.questionId);
      question.loadAnswer(answer);
    });
    this._last_saved_time = jsonObject._last_saved_time;
    this._last_submitted_time = jsonObject._last_submitted_time;
    this._question_language = jsonObject._question_language;
  }

  translationNamespace() {
    return 'questionnaire-' + this._id;
  }

  // Load all the available translatinons from the supplied json object
  loadTranslations(i18n, languages) {
    Object.keys(languages).forEach(language_code => {
      i18n.addResourceBundle(
        language_code,
        this.translationNamespace(),
        languages[language_code],
        true,
        true,
      );
    });
  }

  toJSON() {
    let jsonObject = super.toJSON();
    // we can't know the display language when the questionnaire is loaded,
    // so don't save it.
    delete jsonObject['_question_language'];
    // _last_saved_time and _last_submitted_time are saved as part of
    // the answers document
    delete jsonObject['_last_saved_time'];
    delete jsonObject['_last_submitted_time'];
    return jsonObject;
  }

  // After loading from JSON, convert references to question by id back to
  // actual objects.
  postJSONLoad() {
    super.postJSONLoad();
    if (this._date_generated) {
      this._date_generated = new Date(this._date_generated);
    }
    if (this._published_date) {
      this._published_date = new Date(this._published_date);
    }
    if (this._submission_deadline) {
      this._submission_deadline = new Date(this._submission_deadline);
    }
    this._questions.forEach(q => q.postJSONLoad(this));
  }
}

class PpTrueCondition extends PpActivationCondition {

    isActive() {
        return true;
    }
}

//
// Global ID allocation for Questionnaire components
//
// Ideally, once the questionnaire goes public, any changes to 
// questions, e.g. different choices of words, emphasis, etc.,
// should be tracked so that the impact from those changes
// can be properly tracked and analysed.
//
// Having central allocation of IDs allows this to be set up.
//
// Curently the ID starts at the default value each time the program
// is run, however it can be loaded from a central store to
// properly provide IDs.
//

var nextGId = 1;

function nextGlobalId() {
    return nextGId++;
}

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _defineProperty$1(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _objectSpread$3(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? Object(arguments[i]) : {};
    var ownKeys = Object.keys(source);

    if (typeof Object.getOwnPropertySymbols === 'function') {
      ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      _defineProperty$1(target, key, source[key]);
    });
  }

  return target;
}

function _classCallCheck$1(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties$1(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass$1(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties$1(Constructor, staticProps);
  return Constructor;
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

var consoleLogger = {
  type: 'logger',
  log: function log(args) {
    this.output('log', args);
  },
  warn: function warn(args) {
    this.output('warn', args);
  },
  error: function error(args) {
    this.output('error', args);
  },
  output: function output(type, args) {
    if (console && console[type]) console[type].apply(console, args);
  }
};

var Logger = function () {
  function Logger(concreteLogger) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck$1(this, Logger);

    this.init(concreteLogger, options);
  }

  _createClass$1(Logger, [{
    key: "init",
    value: function init(concreteLogger) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      this.prefix = options.prefix || 'i18next:';
      this.logger = concreteLogger || consoleLogger;
      this.options = options;
      this.debug = options.debug;
    }
  }, {
    key: "setDebug",
    value: function setDebug(bool) {
      this.debug = bool;
    }
  }, {
    key: "log",
    value: function log() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return this.forward(args, 'log', '', true);
    }
  }, {
    key: "warn",
    value: function warn() {
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }

      return this.forward(args, 'warn', '', true);
    }
  }, {
    key: "error",
    value: function error() {
      for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        args[_key3] = arguments[_key3];
      }

      return this.forward(args, 'error', '');
    }
  }, {
    key: "deprecate",
    value: function deprecate() {
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        args[_key4] = arguments[_key4];
      }

      return this.forward(args, 'warn', 'WARNING DEPRECATED: ', true);
    }
  }, {
    key: "forward",
    value: function forward(args, lvl, prefix, debugOnly) {
      if (debugOnly && !this.debug) return null;
      if (typeof args[0] === 'string') args[0] = "".concat(prefix).concat(this.prefix, " ").concat(args[0]);
      return this.logger[lvl](args);
    }
  }, {
    key: "create",
    value: function create(moduleName) {
      return new Logger(this.logger, _objectSpread$3({}, {
        prefix: "".concat(this.prefix, ":").concat(moduleName, ":")
      }, this.options));
    }
  }]);

  return Logger;
}();

var baseLogger = new Logger();

var EventEmitter = function () {
  function EventEmitter() {
    _classCallCheck$1(this, EventEmitter);

    this.observers = {};
  }

  _createClass$1(EventEmitter, [{
    key: "on",
    value: function on(events, listener) {
      var _this = this;

      events.split(' ').forEach(function (event) {
        _this.observers[event] = _this.observers[event] || [];

        _this.observers[event].push(listener);
      });
      return this;
    }
  }, {
    key: "off",
    value: function off(event, listener) {
      if (!this.observers[event]) return;

      if (!listener) {
        delete this.observers[event];
        return;
      }

      this.observers[event] = this.observers[event].filter(function (l) {
        return l !== listener;
      });
    }
  }, {
    key: "emit",
    value: function emit(event) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      if (this.observers[event]) {
        var cloned = [].concat(this.observers[event]);
        cloned.forEach(function (observer) {
          observer.apply(void 0, args);
        });
      }

      if (this.observers['*']) {
        var _cloned = [].concat(this.observers['*']);

        _cloned.forEach(function (observer) {
          observer.apply(observer, [event].concat(args));
        });
      }
    }
  }]);

  return EventEmitter;
}();

function defer() {
  var res;
  var rej;
  var promise = new Promise(function (resolve, reject) {
    res = resolve;
    rej = reject;
  });
  promise.resolve = res;
  promise.reject = rej;
  return promise;
}
function makeString(object) {
  if (object == null) return '';
  return '' + object;
}
function copy(a, s, t) {
  a.forEach(function (m) {
    if (s[m]) t[m] = s[m];
  });
}

function getLastOfPath(object, path, Empty) {
  function cleanKey(key) {
    return key && key.indexOf('###') > -1 ? key.replace(/###/g, '.') : key;
  }

  function canNotTraverseDeeper() {
    return !object || typeof object === 'string';
  }

  var stack = typeof path !== 'string' ? [].concat(path) : path.split('.');

  while (stack.length > 1) {
    if (canNotTraverseDeeper()) return {};
    var key = cleanKey(stack.shift());
    if (!object[key] && Empty) object[key] = new Empty();
    object = object[key];
  }

  if (canNotTraverseDeeper()) return {};
  return {
    obj: object,
    k: cleanKey(stack.shift())
  };
}

function setPath(object, path, newValue) {
  var _getLastOfPath = getLastOfPath(object, path, Object),
      obj = _getLastOfPath.obj,
      k = _getLastOfPath.k;

  obj[k] = newValue;
}
function pushPath(object, path, newValue, concat) {
  var _getLastOfPath2 = getLastOfPath(object, path, Object),
      obj = _getLastOfPath2.obj,
      k = _getLastOfPath2.k;

  obj[k] = obj[k] || [];
  if (concat) obj[k] = obj[k].concat(newValue);
  if (!concat) obj[k].push(newValue);
}
function getPath(object, path) {
  var _getLastOfPath3 = getLastOfPath(object, path),
      obj = _getLastOfPath3.obj,
      k = _getLastOfPath3.k;

  if (!obj) return undefined;
  return obj[k];
}
function getPathWithDefaults(data, defaultData, key) {
  var value = getPath(data, key);

  if (value !== undefined) {
    return value;
  }

  return getPath(defaultData, key);
}
function deepExtend(target, source, overwrite) {
  for (var prop in source) {
    if (prop !== '__proto__') {
      if (prop in target) {
        if (typeof target[prop] === 'string' || target[prop] instanceof String || typeof source[prop] === 'string' || source[prop] instanceof String) {
          if (overwrite) target[prop] = source[prop];
        } else {
          deepExtend(target[prop], source[prop], overwrite);
        }
      } else {
        target[prop] = source[prop];
      }
    }
  }

  return target;
}
function regexEscape(str) {
  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
}
var _entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '/': '&#x2F;'
};
function escape(data) {
  if (typeof data === 'string') {
    return data.replace(/[&<>"'\/]/g, function (s) {
      return _entityMap[s];
    });
  }

  return data;
}
var isIE10 = typeof window !== 'undefined' && window.navigator && window.navigator.userAgent && window.navigator.userAgent.indexOf('MSIE') > -1;

var ResourceStore = function (_EventEmitter) {
  _inherits(ResourceStore, _EventEmitter);

  function ResourceStore(data) {
    var _this;

    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
      ns: ['translation'],
      defaultNS: 'translation'
    };

    _classCallCheck$1(this, ResourceStore);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ResourceStore).call(this));

    if (isIE10) {
      EventEmitter.call(_assertThisInitialized(_this));
    }

    _this.data = data || {};
    _this.options = options;

    if (_this.options.keySeparator === undefined) {
      _this.options.keySeparator = '.';
    }

    return _this;
  }

  _createClass$1(ResourceStore, [{
    key: "addNamespaces",
    value: function addNamespaces(ns) {
      if (this.options.ns.indexOf(ns) < 0) {
        this.options.ns.push(ns);
      }
    }
  }, {
    key: "removeNamespaces",
    value: function removeNamespaces(ns) {
      var index = this.options.ns.indexOf(ns);

      if (index > -1) {
        this.options.ns.splice(index, 1);
      }
    }
  }, {
    key: "getResource",
    value: function getResource(lng, ns, key) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      var keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
      var path = [lng, ns];
      if (key && typeof key !== 'string') path = path.concat(key);
      if (key && typeof key === 'string') path = path.concat(keySeparator ? key.split(keySeparator) : key);

      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
      }

      return getPath(this.data, path);
    }
  }, {
    key: "addResource",
    value: function addResource(lng, ns, key, value) {
      var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {
        silent: false
      };
      var keySeparator = this.options.keySeparator;
      if (keySeparator === undefined) keySeparator = '.';
      var path = [lng, ns];
      if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);

      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
        value = ns;
        ns = path[1];
      }

      this.addNamespaces(ns);
      setPath(this.data, path, value);
      if (!options.silent) this.emit('added', lng, ns, key, value);
    }
  }, {
    key: "addResources",
    value: function addResources(lng, ns, resources) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {
        silent: false
      };

      for (var m in resources) {
        if (typeof resources[m] === 'string' || Object.prototype.toString.apply(resources[m]) === '[object Array]') this.addResource(lng, ns, m, resources[m], {
          silent: true
        });
      }

      if (!options.silent) this.emit('added', lng, ns, resources);
    }
  }, {
    key: "addResourceBundle",
    value: function addResourceBundle(lng, ns, resources, deep, overwrite) {
      var options = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : {
        silent: false
      };
      var path = [lng, ns];

      if (lng.indexOf('.') > -1) {
        path = lng.split('.');
        deep = resources;
        resources = ns;
        ns = path[1];
      }

      this.addNamespaces(ns);
      var pack = getPath(this.data, path) || {};

      if (deep) {
        deepExtend(pack, resources, overwrite);
      } else {
        pack = _objectSpread$3({}, pack, resources);
      }

      setPath(this.data, path, pack);
      if (!options.silent) this.emit('added', lng, ns, resources);
    }
  }, {
    key: "removeResourceBundle",
    value: function removeResourceBundle(lng, ns) {
      if (this.hasResourceBundle(lng, ns)) {
        delete this.data[lng][ns];
      }

      this.removeNamespaces(ns);
      this.emit('removed', lng, ns);
    }
  }, {
    key: "hasResourceBundle",
    value: function hasResourceBundle(lng, ns) {
      return this.getResource(lng, ns) !== undefined;
    }
  }, {
    key: "getResourceBundle",
    value: function getResourceBundle(lng, ns) {
      if (!ns) ns = this.options.defaultNS;
      if (this.options.compatibilityAPI === 'v1') return _objectSpread$3({}, {}, this.getResource(lng, ns));
      return this.getResource(lng, ns);
    }
  }, {
    key: "getDataByLanguage",
    value: function getDataByLanguage(lng) {
      return this.data[lng];
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.data;
    }
  }]);

  return ResourceStore;
}(EventEmitter);

var postProcessor = {
  processors: {},
  addPostProcessor: function addPostProcessor(module) {
    this.processors[module.name] = module;
  },
  handle: function handle(processors, value, key, options, translator) {
    var _this = this;

    processors.forEach(function (processor) {
      if (_this.processors[processor]) value = _this.processors[processor].process(value, key, options, translator);
    });
    return value;
  }
};

var checkedLoadedFor = {};

var Translator = function (_EventEmitter) {
  _inherits(Translator, _EventEmitter);

  function Translator(services) {
    var _this;

    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck$1(this, Translator);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(Translator).call(this));

    if (isIE10) {
      EventEmitter.call(_assertThisInitialized(_this));
    }

    copy(['resourceStore', 'languageUtils', 'pluralResolver', 'interpolator', 'backendConnector', 'i18nFormat', 'utils'], services, _assertThisInitialized(_this));
    _this.options = options;

    if (_this.options.keySeparator === undefined) {
      _this.options.keySeparator = '.';
    }

    _this.logger = baseLogger.create('translator');
    return _this;
  }

  _createClass$1(Translator, [{
    key: "changeLanguage",
    value: function changeLanguage(lng) {
      if (lng) this.language = lng;
    }
  }, {
    key: "exists",
    value: function exists(key) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
        interpolation: {}
      };
      var resolved = this.resolve(key, options);
      return resolved && resolved.res !== undefined;
    }
  }, {
    key: "extractFromKey",
    value: function extractFromKey(key, options) {
      var nsSeparator = options.nsSeparator !== undefined ? options.nsSeparator : this.options.nsSeparator;
      if (nsSeparator === undefined) nsSeparator = ':';
      var keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
      var namespaces = options.ns || this.options.defaultNS;

      if (nsSeparator && key.indexOf(nsSeparator) > -1) {
        var m = key.match(this.interpolator.nestingRegexp);

        if (m && m.length > 0) {
          return {
            key: key,
            namespaces: namespaces
          };
        }

        var parts = key.split(nsSeparator);
        if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1) namespaces = parts.shift();
        key = parts.join(keySeparator);
      }

      if (typeof namespaces === 'string') namespaces = [namespaces];
      return {
        key: key,
        namespaces: namespaces
      };
    }
  }, {
    key: "translate",
    value: function translate(keys, options, lastKey) {
      var _this2 = this;

      if (_typeof(options) !== 'object' && this.options.overloadTranslationOptionHandler) {
        options = this.options.overloadTranslationOptionHandler(arguments);
      }

      if (!options) options = {};
      if (keys === undefined || keys === null) return '';
      if (!Array.isArray(keys)) keys = [String(keys)];
      var keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;

      var _this$extractFromKey = this.extractFromKey(keys[keys.length - 1], options),
          key = _this$extractFromKey.key,
          namespaces = _this$extractFromKey.namespaces;

      var namespace = namespaces[namespaces.length - 1];
      var lng = options.lng || this.language;
      var appendNamespaceToCIMode = options.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;

      if (lng && lng.toLowerCase() === 'cimode') {
        if (appendNamespaceToCIMode) {
          var nsSeparator = options.nsSeparator || this.options.nsSeparator;
          return namespace + nsSeparator + key;
        }

        return key;
      }

      var resolved = this.resolve(keys, options);
      var res = resolved && resolved.res;
      var resUsedKey = resolved && resolved.usedKey || key;
      var resExactUsedKey = resolved && resolved.exactUsedKey || key;
      var resType = Object.prototype.toString.apply(res);
      var noObject = ['[object Number]', '[object Function]', '[object RegExp]'];
      var joinArrays = options.joinArrays !== undefined ? options.joinArrays : this.options.joinArrays;
      var handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
      var handleAsObject = typeof res !== 'string' && typeof res !== 'boolean' && typeof res !== 'number';

      if (handleAsObjectInI18nFormat && res && handleAsObject && noObject.indexOf(resType) < 0 && !(typeof joinArrays === 'string' && resType === '[object Array]')) {
        if (!options.returnObjects && !this.options.returnObjects) {
          this.logger.warn('accessing an object - but returnObjects options is not enabled!');
          return this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, res, options) : "key '".concat(key, " (").concat(this.language, ")' returned an object instead of string.");
        }

        if (keySeparator) {
          var resTypeIsArray = resType === '[object Array]';
          var copy$$1 = resTypeIsArray ? [] : {};
          var newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;

          for (var m in res) {
            if (Object.prototype.hasOwnProperty.call(res, m)) {
              var deepKey = "".concat(newKeyToUse).concat(keySeparator).concat(m);
              copy$$1[m] = this.translate(deepKey, _objectSpread$3({}, options, {
                joinArrays: false,
                ns: namespaces
              }));
              if (copy$$1[m] === deepKey) copy$$1[m] = res[m];
            }
          }

          res = copy$$1;
        }
      } else if (handleAsObjectInI18nFormat && typeof joinArrays === 'string' && resType === '[object Array]') {
        res = res.join(joinArrays);
        if (res) res = this.extendTranslation(res, keys, options, lastKey);
      } else {
        var usedDefault = false;
        var usedKey = false;

        if (!this.isValidLookup(res) && options.defaultValue !== undefined) {
          usedDefault = true;

          if (options.count !== undefined) {
            var suffix = this.pluralResolver.getSuffix(lng, options.count);
            res = options["defaultValue".concat(suffix)];
          }

          if (!res) res = options.defaultValue;
        }

        if (!this.isValidLookup(res)) {
          usedKey = true;
          res = key;
        }

        var updateMissing = options.defaultValue && options.defaultValue !== res && this.options.updateMissing;

        if (usedKey || usedDefault || updateMissing) {
          this.logger.log(updateMissing ? 'updateKey' : 'missingKey', lng, namespace, key, updateMissing ? options.defaultValue : res);

          if (keySeparator) {
            var fk = this.resolve(key, _objectSpread$3({}, options, {
              keySeparator: false
            }));
            if (fk && fk.res) this.logger.warn('Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.');
          }

          var lngs = [];
          var fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, options.lng || this.language);

          if (this.options.saveMissingTo === 'fallback' && fallbackLngs && fallbackLngs[0]) {
            for (var i = 0; i < fallbackLngs.length; i++) {
              lngs.push(fallbackLngs[i]);
            }
          } else if (this.options.saveMissingTo === 'all') {
            lngs = this.languageUtils.toResolveHierarchy(options.lng || this.language);
          } else {
            lngs.push(options.lng || this.language);
          }

          var send = function send(l, k) {
            if (_this2.options.missingKeyHandler) {
              _this2.options.missingKeyHandler(l, namespace, k, updateMissing ? options.defaultValue : res, updateMissing, options);
            } else if (_this2.backendConnector && _this2.backendConnector.saveMissing) {
              _this2.backendConnector.saveMissing(l, namespace, k, updateMissing ? options.defaultValue : res, updateMissing, options);
            }

            _this2.emit('missingKey', l, namespace, k, res);
          };

          if (this.options.saveMissing) {
            var needsPluralHandling = options.count !== undefined && typeof options.count !== 'string';

            if (this.options.saveMissingPlurals && needsPluralHandling) {
              lngs.forEach(function (l) {
                var plurals = _this2.pluralResolver.getPluralFormsOfKey(l, key);

                plurals.forEach(function (p) {
                  return send([l], p);
                });
              });
            } else {
              send(lngs, key);
            }
          }
        }

        res = this.extendTranslation(res, keys, options, resolved, lastKey);
        if (usedKey && res === key && this.options.appendNamespaceToMissingKey) res = "".concat(namespace, ":").concat(key);
        if (usedKey && this.options.parseMissingKeyHandler) res = this.options.parseMissingKeyHandler(res);
      }

      return res;
    }
  }, {
    key: "extendTranslation",
    value: function extendTranslation(res, key, options, resolved, lastKey) {
      var _this3 = this;

      if (this.i18nFormat && this.i18nFormat.parse) {
        res = this.i18nFormat.parse(res, options, resolved.usedLng, resolved.usedNS, resolved.usedKey, {
          resolved: resolved
        });
      } else if (!options.skipInterpolation) {
        if (options.interpolation) this.interpolator.init(_objectSpread$3({}, options, {
          interpolation: _objectSpread$3({}, this.options.interpolation, options.interpolation)
        }));
        var skipOnVariables = options.interpolation && options.interpolation.skipOnVariables || this.options.interpolation.skipOnVariables;
        var nestBef;

        if (skipOnVariables) {
          var nb = res.match(this.interpolator.nestingRegexp);
          nestBef = nb && nb.length;
        }

        var data = options.replace && typeof options.replace !== 'string' ? options.replace : options;
        if (this.options.interpolation.defaultVariables) data = _objectSpread$3({}, this.options.interpolation.defaultVariables, data);
        res = this.interpolator.interpolate(res, data, options.lng || this.language, options);

        if (skipOnVariables) {
          var na = res.match(this.interpolator.nestingRegexp);
          var nestAft = na && na.length;
          if (nestBef < nestAft) options.nest = false;
        }

        if (options.nest !== false) res = this.interpolator.nest(res, function () {
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          if (lastKey && lastKey[0] === args[0]) {
            _this3.logger.warn("It seems you are nesting recursively key: ".concat(args[0], " in key: ").concat(key[0]));

            return null;
          }

          return _this3.translate.apply(_this3, args.concat([key]));
        }, options);
        if (options.interpolation) this.interpolator.reset();
      }

      var postProcess = options.postProcess || this.options.postProcess;
      var postProcessorNames = typeof postProcess === 'string' ? [postProcess] : postProcess;

      if (res !== undefined && res !== null && postProcessorNames && postProcessorNames.length && options.applyPostProcessor !== false) {
        res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? _objectSpread$3({
          i18nResolved: resolved
        }, options) : options, this);
      }

      return res;
    }
  }, {
    key: "resolve",
    value: function resolve(keys) {
      var _this4 = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var found;
      var usedKey;
      var exactUsedKey;
      var usedLng;
      var usedNS;
      if (typeof keys === 'string') keys = [keys];
      keys.forEach(function (k) {
        if (_this4.isValidLookup(found)) return;

        var extracted = _this4.extractFromKey(k, options);

        var key = extracted.key;
        usedKey = key;
        var namespaces = extracted.namespaces;
        if (_this4.options.fallbackNS) namespaces = namespaces.concat(_this4.options.fallbackNS);
        var needsPluralHandling = options.count !== undefined && typeof options.count !== 'string';
        var needsContextHandling = options.context !== undefined && typeof options.context === 'string' && options.context !== '';
        var codes = options.lngs ? options.lngs : _this4.languageUtils.toResolveHierarchy(options.lng || _this4.language, options.fallbackLng);
        namespaces.forEach(function (ns) {
          if (_this4.isValidLookup(found)) return;
          usedNS = ns;

          if (!checkedLoadedFor["".concat(codes[0], "-").concat(ns)] && _this4.utils && _this4.utils.hasLoadedNamespace && !_this4.utils.hasLoadedNamespace(usedNS)) {
            checkedLoadedFor["".concat(codes[0], "-").concat(ns)] = true;

            _this4.logger.warn("key \"".concat(usedKey, "\" for languages \"").concat(codes.join(', '), "\" won't get resolved as namespace \"").concat(usedNS, "\" was not yet loaded"), 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
          }

          codes.forEach(function (code) {
            if (_this4.isValidLookup(found)) return;
            usedLng = code;
            var finalKey = key;
            var finalKeys = [finalKey];

            if (_this4.i18nFormat && _this4.i18nFormat.addLookupKeys) {
              _this4.i18nFormat.addLookupKeys(finalKeys, key, code, ns, options);
            } else {
              var pluralSuffix;
              if (needsPluralHandling) pluralSuffix = _this4.pluralResolver.getSuffix(code, options.count);
              if (needsPluralHandling && needsContextHandling) finalKeys.push(finalKey + pluralSuffix);
              if (needsContextHandling) finalKeys.push(finalKey += "".concat(_this4.options.contextSeparator).concat(options.context));
              if (needsPluralHandling) finalKeys.push(finalKey += pluralSuffix);
            }

            var possibleKey;

            while (possibleKey = finalKeys.pop()) {
              if (!_this4.isValidLookup(found)) {
                exactUsedKey = possibleKey;
                found = _this4.getResource(code, ns, possibleKey, options);
              }
            }
          });
        });
      });
      return {
        res: found,
        usedKey: usedKey,
        exactUsedKey: exactUsedKey,
        usedLng: usedLng,
        usedNS: usedNS
      };
    }
  }, {
    key: "isValidLookup",
    value: function isValidLookup(res) {
      return res !== undefined && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === '');
    }
  }, {
    key: "getResource",
    value: function getResource(code, ns, key) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      if (this.i18nFormat && this.i18nFormat.getResource) return this.i18nFormat.getResource(code, ns, key, options);
      return this.resourceStore.getResource(code, ns, key, options);
    }
  }]);

  return Translator;
}(EventEmitter);

function capitalize(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

var LanguageUtil = function () {
  function LanguageUtil(options) {
    _classCallCheck$1(this, LanguageUtil);

    this.options = options;
    this.whitelist = this.options.supportedLngs || false;
    this.supportedLngs = this.options.supportedLngs || false;
    this.logger = baseLogger.create('languageUtils');
  }

  _createClass$1(LanguageUtil, [{
    key: "getScriptPartFromCode",
    value: function getScriptPartFromCode(code) {
      if (!code || code.indexOf('-') < 0) return null;
      var p = code.split('-');
      if (p.length === 2) return null;
      p.pop();
      if (p[p.length - 1].toLowerCase() === 'x') return null;
      return this.formatLanguageCode(p.join('-'));
    }
  }, {
    key: "getLanguagePartFromCode",
    value: function getLanguagePartFromCode(code) {
      if (!code || code.indexOf('-') < 0) return code;
      var p = code.split('-');
      return this.formatLanguageCode(p[0]);
    }
  }, {
    key: "formatLanguageCode",
    value: function formatLanguageCode(code) {
      if (typeof code === 'string' && code.indexOf('-') > -1) {
        var specialCases = ['hans', 'hant', 'latn', 'cyrl', 'cans', 'mong', 'arab'];
        var p = code.split('-');

        if (this.options.lowerCaseLng) {
          p = p.map(function (part) {
            return part.toLowerCase();
          });
        } else if (p.length === 2) {
          p[0] = p[0].toLowerCase();
          p[1] = p[1].toUpperCase();
          if (specialCases.indexOf(p[1].toLowerCase()) > -1) p[1] = capitalize(p[1].toLowerCase());
        } else if (p.length === 3) {
          p[0] = p[0].toLowerCase();
          if (p[1].length === 2) p[1] = p[1].toUpperCase();
          if (p[0] !== 'sgn' && p[2].length === 2) p[2] = p[2].toUpperCase();
          if (specialCases.indexOf(p[1].toLowerCase()) > -1) p[1] = capitalize(p[1].toLowerCase());
          if (specialCases.indexOf(p[2].toLowerCase()) > -1) p[2] = capitalize(p[2].toLowerCase());
        }

        return p.join('-');
      }

      return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
    }
  }, {
    key: "isWhitelisted",
    value: function isWhitelisted(code) {
      this.logger.deprecate('languageUtils.isWhitelisted', 'function "isWhitelisted" will be renamed to "isSupportedCode" in the next major - please make sure to rename it\'s usage asap.');
      return this.isSupportedCode(code);
    }
  }, {
    key: "isSupportedCode",
    value: function isSupportedCode(code) {
      if (this.options.load === 'languageOnly' || this.options.nonExplicitSupportedLngs) {
        code = this.getLanguagePartFromCode(code);
      }

      return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
    }
  }, {
    key: "getBestMatchFromCodes",
    value: function getBestMatchFromCodes(codes) {
      var _this = this;

      if (!codes) return null;
      var found;
      codes.forEach(function (code) {
        if (found) return;

        var cleanedLng = _this.formatLanguageCode(code);

        if (!_this.options.supportedLngs || _this.isSupportedCode(cleanedLng)) found = cleanedLng;
      });

      if (!found && this.options.supportedLngs) {
        codes.forEach(function (code) {
          if (found) return;

          var lngOnly = _this.getLanguagePartFromCode(code);

          if (_this.isSupportedCode(lngOnly)) return found = lngOnly;
          found = _this.options.supportedLngs.find(function (supportedLng) {
            if (supportedLng.indexOf(lngOnly) === 0) return supportedLng;
          });
        });
      }

      if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
      return found;
    }
  }, {
    key: "getFallbackCodes",
    value: function getFallbackCodes(fallbacks, code) {
      if (!fallbacks) return [];
      if (typeof fallbacks === 'string') fallbacks = [fallbacks];
      if (Object.prototype.toString.apply(fallbacks) === '[object Array]') return fallbacks;
      if (!code) return fallbacks["default"] || [];
      var found = fallbacks[code];
      if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
      if (!found) found = fallbacks[this.formatLanguageCode(code)];
      if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
      if (!found) found = fallbacks["default"];
      return found || [];
    }
  }, {
    key: "toResolveHierarchy",
    value: function toResolveHierarchy(code, fallbackCode) {
      var _this2 = this;

      var fallbackCodes = this.getFallbackCodes(fallbackCode || this.options.fallbackLng || [], code);
      var codes = [];

      var addCode = function addCode(c) {
        if (!c) return;

        if (_this2.isSupportedCode(c)) {
          codes.push(c);
        } else {
          _this2.logger.warn("rejecting language code not found in supportedLngs: ".concat(c));
        }
      };

      if (typeof code === 'string' && code.indexOf('-') > -1) {
        if (this.options.load !== 'languageOnly') addCode(this.formatLanguageCode(code));
        if (this.options.load !== 'languageOnly' && this.options.load !== 'currentOnly') addCode(this.getScriptPartFromCode(code));
        if (this.options.load !== 'currentOnly') addCode(this.getLanguagePartFromCode(code));
      } else if (typeof code === 'string') {
        addCode(this.formatLanguageCode(code));
      }

      fallbackCodes.forEach(function (fc) {
        if (codes.indexOf(fc) < 0) addCode(_this2.formatLanguageCode(fc));
      });
      return codes;
    }
  }]);

  return LanguageUtil;
}();

var sets = [{
  lngs: ['ach', 'ak', 'am', 'arn', 'br', 'fil', 'gun', 'ln', 'mfe', 'mg', 'mi', 'oc', 'pt', 'pt-BR', 'tg', 'ti', 'tr', 'uz', 'wa'],
  nr: [1, 2],
  fc: 1
}, {
  lngs: ['af', 'an', 'ast', 'az', 'bg', 'bn', 'ca', 'da', 'de', 'dev', 'el', 'en', 'eo', 'es', 'et', 'eu', 'fi', 'fo', 'fur', 'fy', 'gl', 'gu', 'ha', 'hi', 'hu', 'hy', 'ia', 'it', 'kn', 'ku', 'lb', 'mai', 'ml', 'mn', 'mr', 'nah', 'nap', 'nb', 'ne', 'nl', 'nn', 'no', 'nso', 'pa', 'pap', 'pms', 'ps', 'pt-PT', 'rm', 'sco', 'se', 'si', 'so', 'son', 'sq', 'sv', 'sw', 'ta', 'te', 'tk', 'ur', 'yo'],
  nr: [1, 2],
  fc: 2
}, {
  lngs: ['ay', 'bo', 'cgg', 'fa', 'ht', 'id', 'ja', 'jbo', 'ka', 'kk', 'km', 'ko', 'ky', 'lo', 'ms', 'sah', 'su', 'th', 'tt', 'ug', 'vi', 'wo', 'zh'],
  nr: [1],
  fc: 3
}, {
  lngs: ['be', 'bs', 'cnr', 'dz', 'hr', 'ru', 'sr', 'uk'],
  nr: [1, 2, 5],
  fc: 4
}, {
  lngs: ['ar'],
  nr: [0, 1, 2, 3, 11, 100],
  fc: 5
}, {
  lngs: ['cs', 'sk'],
  nr: [1, 2, 5],
  fc: 6
}, {
  lngs: ['csb', 'pl'],
  nr: [1, 2, 5],
  fc: 7
}, {
  lngs: ['cy'],
  nr: [1, 2, 3, 8],
  fc: 8
}, {
  lngs: ['fr'],
  nr: [1, 2],
  fc: 9
}, {
  lngs: ['ga'],
  nr: [1, 2, 3, 7, 11],
  fc: 10
}, {
  lngs: ['gd'],
  nr: [1, 2, 3, 20],
  fc: 11
}, {
  lngs: ['is'],
  nr: [1, 2],
  fc: 12
}, {
  lngs: ['jv'],
  nr: [0, 1],
  fc: 13
}, {
  lngs: ['kw'],
  nr: [1, 2, 3, 4],
  fc: 14
}, {
  lngs: ['lt'],
  nr: [1, 2, 10],
  fc: 15
}, {
  lngs: ['lv'],
  nr: [1, 2, 0],
  fc: 16
}, {
  lngs: ['mk'],
  nr: [1, 2],
  fc: 17
}, {
  lngs: ['mnk'],
  nr: [0, 1, 2],
  fc: 18
}, {
  lngs: ['mt'],
  nr: [1, 2, 11, 20],
  fc: 19
}, {
  lngs: ['or'],
  nr: [2, 1],
  fc: 2
}, {
  lngs: ['ro'],
  nr: [1, 2, 20],
  fc: 20
}, {
  lngs: ['sl'],
  nr: [5, 1, 2, 3],
  fc: 21
}, {
  lngs: ['he', 'iw'],
  nr: [1, 2, 20, 21],
  fc: 22
}];
var _rulesPluralsTypes = {
  1: function _(n) {
    return Number(n > 1);
  },
  2: function _(n) {
    return Number(n != 1);
  },
  3: function _(n) {
    return 0;
  },
  4: function _(n) {
    return Number(n % 10 == 1 && n % 100 != 11 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2);
  },
  5: function _(n) {
    return Number(n == 0 ? 0 : n == 1 ? 1 : n == 2 ? 2 : n % 100 >= 3 && n % 100 <= 10 ? 3 : n % 100 >= 11 ? 4 : 5);
  },
  6: function _(n) {
    return Number(n == 1 ? 0 : n >= 2 && n <= 4 ? 1 : 2);
  },
  7: function _(n) {
    return Number(n == 1 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2);
  },
  8: function _(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : n != 8 && n != 11 ? 2 : 3);
  },
  9: function _(n) {
    return Number(n >= 2);
  },
  10: function _(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : n < 7 ? 2 : n < 11 ? 3 : 4);
  },
  11: function _(n) {
    return Number(n == 1 || n == 11 ? 0 : n == 2 || n == 12 ? 1 : n > 2 && n < 20 ? 2 : 3);
  },
  12: function _(n) {
    return Number(n % 10 != 1 || n % 100 == 11);
  },
  13: function _(n) {
    return Number(n !== 0);
  },
  14: function _(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : n == 3 ? 2 : 3);
  },
  15: function _(n) {
    return Number(n % 10 == 1 && n % 100 != 11 ? 0 : n % 10 >= 2 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2);
  },
  16: function _(n) {
    return Number(n % 10 == 1 && n % 100 != 11 ? 0 : n !== 0 ? 1 : 2);
  },
  17: function _(n) {
    return Number(n == 1 || n % 10 == 1 && n % 100 != 11 ? 0 : 1);
  },
  18: function _(n) {
    return Number(n == 0 ? 0 : n == 1 ? 1 : 2);
  },
  19: function _(n) {
    return Number(n == 1 ? 0 : n == 0 || n % 100 > 1 && n % 100 < 11 ? 1 : n % 100 > 10 && n % 100 < 20 ? 2 : 3);
  },
  20: function _(n) {
    return Number(n == 1 ? 0 : n == 0 || n % 100 > 0 && n % 100 < 20 ? 1 : 2);
  },
  21: function _(n) {
    return Number(n % 100 == 1 ? 1 : n % 100 == 2 ? 2 : n % 100 == 3 || n % 100 == 4 ? 3 : 0);
  },
  22: function _(n) {
    return Number(n == 1 ? 0 : n == 2 ? 1 : (n < 0 || n > 10) && n % 10 == 0 ? 2 : 3);
  }
};

function createRules() {
  var rules = {};
  sets.forEach(function (set) {
    set.lngs.forEach(function (l) {
      rules[l] = {
        numbers: set.nr,
        plurals: _rulesPluralsTypes[set.fc]
      };
    });
  });
  return rules;
}

var PluralResolver = function () {
  function PluralResolver(languageUtils) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck$1(this, PluralResolver);

    this.languageUtils = languageUtils;
    this.options = options;
    this.logger = baseLogger.create('pluralResolver');
    this.rules = createRules();
  }

  _createClass$1(PluralResolver, [{
    key: "addRule",
    value: function addRule(lng, obj) {
      this.rules[lng] = obj;
    }
  }, {
    key: "getRule",
    value: function getRule(code) {
      return this.rules[code] || this.rules[this.languageUtils.getLanguagePartFromCode(code)];
    }
  }, {
    key: "needsPlural",
    value: function needsPlural(code) {
      var rule = this.getRule(code);
      return rule && rule.numbers.length > 1;
    }
  }, {
    key: "getPluralFormsOfKey",
    value: function getPluralFormsOfKey(code, key) {
      var _this = this;

      var ret = [];
      var rule = this.getRule(code);
      if (!rule) return ret;
      rule.numbers.forEach(function (n) {
        var suffix = _this.getSuffix(code, n);

        ret.push("".concat(key).concat(suffix));
      });
      return ret;
    }
  }, {
    key: "getSuffix",
    value: function getSuffix(code, count) {
      var _this2 = this;

      var rule = this.getRule(code);

      if (rule) {
        var idx = rule.noAbs ? rule.plurals(count) : rule.plurals(Math.abs(count));
        var suffix = rule.numbers[idx];

        if (this.options.simplifyPluralSuffix && rule.numbers.length === 2 && rule.numbers[0] === 1) {
          if (suffix === 2) {
            suffix = 'plural';
          } else if (suffix === 1) {
            suffix = '';
          }
        }

        var returnSuffix = function returnSuffix() {
          return _this2.options.prepend && suffix.toString() ? _this2.options.prepend + suffix.toString() : suffix.toString();
        };

        if (this.options.compatibilityJSON === 'v1') {
          if (suffix === 1) return '';
          if (typeof suffix === 'number') return "_plural_".concat(suffix.toString());
          return returnSuffix();
        } else if (this.options.compatibilityJSON === 'v2') {
          return returnSuffix();
        } else if (this.options.simplifyPluralSuffix && rule.numbers.length === 2 && rule.numbers[0] === 1) {
          return returnSuffix();
        }

        return this.options.prepend && idx.toString() ? this.options.prepend + idx.toString() : idx.toString();
      }

      this.logger.warn("no plural rule found for: ".concat(code));
      return '';
    }
  }]);

  return PluralResolver;
}();

var Interpolator = function () {
  function Interpolator() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck$1(this, Interpolator);

    this.logger = baseLogger.create('interpolator');
    this.options = options;

    this.format = options.interpolation && options.interpolation.format || function (value) {
      return value;
    };

    this.init(options);
  }

  _createClass$1(Interpolator, [{
    key: "init",
    value: function init() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      if (!options.interpolation) options.interpolation = {
        escapeValue: true
      };
      var iOpts = options.interpolation;
      this.escape = iOpts.escape !== undefined ? iOpts.escape : escape;
      this.escapeValue = iOpts.escapeValue !== undefined ? iOpts.escapeValue : true;
      this.useRawValueToEscape = iOpts.useRawValueToEscape !== undefined ? iOpts.useRawValueToEscape : false;
      this.prefix = iOpts.prefix ? regexEscape(iOpts.prefix) : iOpts.prefixEscaped || '{{';
      this.suffix = iOpts.suffix ? regexEscape(iOpts.suffix) : iOpts.suffixEscaped || '}}';
      this.formatSeparator = iOpts.formatSeparator ? iOpts.formatSeparator : iOpts.formatSeparator || ',';
      this.unescapePrefix = iOpts.unescapeSuffix ? '' : iOpts.unescapePrefix || '-';
      this.unescapeSuffix = this.unescapePrefix ? '' : iOpts.unescapeSuffix || '';
      this.nestingPrefix = iOpts.nestingPrefix ? regexEscape(iOpts.nestingPrefix) : iOpts.nestingPrefixEscaped || regexEscape('$t(');
      this.nestingSuffix = iOpts.nestingSuffix ? regexEscape(iOpts.nestingSuffix) : iOpts.nestingSuffixEscaped || regexEscape(')');
      this.nestingOptionsSeparator = iOpts.nestingOptionsSeparator ? iOpts.nestingOptionsSeparator : iOpts.nestingOptionsSeparator || ',';
      this.maxReplaces = iOpts.maxReplaces ? iOpts.maxReplaces : 1000;
      this.alwaysFormat = iOpts.alwaysFormat !== undefined ? iOpts.alwaysFormat : false;
      this.resetRegExp();
    }
  }, {
    key: "reset",
    value: function reset() {
      if (this.options) this.init(this.options);
    }
  }, {
    key: "resetRegExp",
    value: function resetRegExp() {
      var regexpStr = "".concat(this.prefix, "(.+?)").concat(this.suffix);
      this.regexp = new RegExp(regexpStr, 'g');
      var regexpUnescapeStr = "".concat(this.prefix).concat(this.unescapePrefix, "(.+?)").concat(this.unescapeSuffix).concat(this.suffix);
      this.regexpUnescape = new RegExp(regexpUnescapeStr, 'g');
      var nestingRegexpStr = "".concat(this.nestingPrefix, "(.+?)").concat(this.nestingSuffix);
      this.nestingRegexp = new RegExp(nestingRegexpStr, 'g');
    }
  }, {
    key: "interpolate",
    value: function interpolate(str, data, lng, options) {
      var _this = this;

      var match;
      var value;
      var replaces;
      var defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};

      function regexSafe(val) {
        return val.replace(/\$/g, '$$$$');
      }

      var handleFormat = function handleFormat(key) {
        if (key.indexOf(_this.formatSeparator) < 0) {
          var path = getPathWithDefaults(data, defaultData, key);
          return _this.alwaysFormat ? _this.format(path, undefined, lng) : path;
        }

        var p = key.split(_this.formatSeparator);
        var k = p.shift().trim();
        var f = p.join(_this.formatSeparator).trim();
        return _this.format(getPathWithDefaults(data, defaultData, k), f, lng, options);
      };

      this.resetRegExp();
      var missingInterpolationHandler = options && options.missingInterpolationHandler || this.options.missingInterpolationHandler;
      var skipOnVariables = options && options.interpolation && options.interpolation.skipOnVariables || this.options.interpolation.skipOnVariables;
      var todos = [{
        regex: this.regexpUnescape,
        safeValue: function safeValue(val) {
          return regexSafe(val);
        }
      }, {
        regex: this.regexp,
        safeValue: function safeValue(val) {
          return _this.escapeValue ? regexSafe(_this.escape(val)) : regexSafe(val);
        }
      }];
      todos.forEach(function (todo) {
        replaces = 0;

        while (match = todo.regex.exec(str)) {
          value = handleFormat(match[1].trim());

          if (value === undefined) {
            if (typeof missingInterpolationHandler === 'function') {
              var temp = missingInterpolationHandler(str, match, options);
              value = typeof temp === 'string' ? temp : '';
            } else if (skipOnVariables) {
              value = match[0];
              continue;
            } else {
              _this.logger.warn("missed to pass in variable ".concat(match[1], " for interpolating ").concat(str));

              value = '';
            }
          } else if (typeof value !== 'string' && !_this.useRawValueToEscape) {
            value = makeString(value);
          }

          str = str.replace(match[0], todo.safeValue(value));
          todo.regex.lastIndex = 0;
          replaces++;

          if (replaces >= _this.maxReplaces) {
            break;
          }
        }
      });
      return str;
    }
  }, {
    key: "nest",
    value: function nest(str, fc) {
      var _this2 = this;

      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      var match;
      var value;

      var clonedOptions = _objectSpread$3({}, options);

      clonedOptions.applyPostProcessor = false;
      delete clonedOptions.defaultValue;

      function handleHasOptions(key, inheritedOptions) {
        var sep = this.nestingOptionsSeparator;
        if (key.indexOf(sep) < 0) return key;
        var c = key.split(new RegExp("".concat(sep, "[ ]*{")));
        var optionsString = "{".concat(c[1]);
        key = c[0];
        optionsString = this.interpolate(optionsString, clonedOptions);
        optionsString = optionsString.replace(/'/g, '"');

        try {
          clonedOptions = JSON.parse(optionsString);
          if (inheritedOptions) clonedOptions = _objectSpread$3({}, inheritedOptions, clonedOptions);
        } catch (e) {
          this.logger.warn("failed parsing options string in nesting for key ".concat(key), e);
          return "".concat(key).concat(sep).concat(optionsString);
        }

        delete clonedOptions.defaultValue;
        return key;
      }

      while (match = this.nestingRegexp.exec(str)) {
        var formatters = [];
        var doReduce = false;

        if (match[0].includes(this.formatSeparator) && !/{.*}/.test(match[1])) {
          var r = match[1].split(this.formatSeparator).map(function (elem) {
            return elem.trim();
          });
          match[1] = r.shift();
          formatters = r;
          doReduce = true;
        }

        value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
        if (value && match[0] === str && typeof value !== 'string') return value;
        if (typeof value !== 'string') value = makeString(value);

        if (!value) {
          this.logger.warn("missed to resolve ".concat(match[1], " for nesting ").concat(str));
          value = '';
        }

        if (doReduce) {
          value = formatters.reduce(function (v, f) {
            return _this2.format(v, f, options.lng, options);
          }, value.trim());
        }

        str = str.replace(match[0], value);
        this.regexp.lastIndex = 0;
      }

      return str;
    }
  }]);

  return Interpolator;
}();

function remove(arr, what) {
  var found = arr.indexOf(what);

  while (found !== -1) {
    arr.splice(found, 1);
    found = arr.indexOf(what);
  }
}

var Connector = function (_EventEmitter) {
  _inherits(Connector, _EventEmitter);

  function Connector(backend, store, services) {
    var _this;

    var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

    _classCallCheck$1(this, Connector);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(Connector).call(this));

    if (isIE10) {
      EventEmitter.call(_assertThisInitialized(_this));
    }

    _this.backend = backend;
    _this.store = store;
    _this.services = services;
    _this.languageUtils = services.languageUtils;
    _this.options = options;
    _this.logger = baseLogger.create('backendConnector');
    _this.state = {};
    _this.queue = [];

    if (_this.backend && _this.backend.init) {
      _this.backend.init(services, options.backend, options);
    }

    return _this;
  }

  _createClass$1(Connector, [{
    key: "queueLoad",
    value: function queueLoad(languages, namespaces, options, callback) {
      var _this2 = this;

      var toLoad = [];
      var pending = [];
      var toLoadLanguages = [];
      var toLoadNamespaces = [];
      languages.forEach(function (lng) {
        var hasAllNamespaces = true;
        namespaces.forEach(function (ns) {
          var name = "".concat(lng, "|").concat(ns);

          if (!options.reload && _this2.store.hasResourceBundle(lng, ns)) {
            _this2.state[name] = 2;
          } else if (_this2.state[name] < 0) ; else if (_this2.state[name] === 1) {
            if (pending.indexOf(name) < 0) pending.push(name);
          } else {
            _this2.state[name] = 1;
            hasAllNamespaces = false;
            if (pending.indexOf(name) < 0) pending.push(name);
            if (toLoad.indexOf(name) < 0) toLoad.push(name);
            if (toLoadNamespaces.indexOf(ns) < 0) toLoadNamespaces.push(ns);
          }
        });
        if (!hasAllNamespaces) toLoadLanguages.push(lng);
      });

      if (toLoad.length || pending.length) {
        this.queue.push({
          pending: pending,
          loaded: {},
          errors: [],
          callback: callback
        });
      }

      return {
        toLoad: toLoad,
        pending: pending,
        toLoadLanguages: toLoadLanguages,
        toLoadNamespaces: toLoadNamespaces
      };
    }
  }, {
    key: "loaded",
    value: function loaded(name, err, data) {
      var s = name.split('|');
      var lng = s[0];
      var ns = s[1];
      if (err) this.emit('failedLoading', lng, ns, err);

      if (data) {
        this.store.addResourceBundle(lng, ns, data);
      }

      this.state[name] = err ? -1 : 2;
      var loaded = {};
      this.queue.forEach(function (q) {
        pushPath(q.loaded, [lng], ns);
        remove(q.pending, name);
        if (err) q.errors.push(err);

        if (q.pending.length === 0 && !q.done) {
          Object.keys(q.loaded).forEach(function (l) {
            if (!loaded[l]) loaded[l] = [];

            if (q.loaded[l].length) {
              q.loaded[l].forEach(function (ns) {
                if (loaded[l].indexOf(ns) < 0) loaded[l].push(ns);
              });
            }
          });
          q.done = true;

          if (q.errors.length) {
            q.callback(q.errors);
          } else {
            q.callback();
          }
        }
      });
      this.emit('loaded', loaded);
      this.queue = this.queue.filter(function (q) {
        return !q.done;
      });
    }
  }, {
    key: "read",
    value: function read(lng, ns, fcName) {
      var _this3 = this;

      var tried = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
      var wait = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 350;
      var callback = arguments.length > 5 ? arguments[5] : undefined;
      if (!lng.length) return callback(null, {});
      return this.backend[fcName](lng, ns, function (err, data) {
        if (err && data && tried < 5) {
          setTimeout(function () {
            _this3.read.call(_this3, lng, ns, fcName, tried + 1, wait * 2, callback);
          }, wait);
          return;
        }

        callback(err, data);
      });
    }
  }, {
    key: "prepareLoading",
    value: function prepareLoading(languages, namespaces) {
      var _this4 = this;

      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      var callback = arguments.length > 3 ? arguments[3] : undefined;

      if (!this.backend) {
        this.logger.warn('No backend was added via i18next.use. Will not load resources.');
        return callback && callback();
      }

      if (typeof languages === 'string') languages = this.languageUtils.toResolveHierarchy(languages);
      if (typeof namespaces === 'string') namespaces = [namespaces];
      var toLoad = this.queueLoad(languages, namespaces, options, callback);

      if (!toLoad.toLoad.length) {
        if (!toLoad.pending.length) callback();
        return null;
      }

      toLoad.toLoad.forEach(function (name) {
        _this4.loadOne(name);
      });
    }
  }, {
    key: "load",
    value: function load(languages, namespaces, callback) {
      this.prepareLoading(languages, namespaces, {}, callback);
    }
  }, {
    key: "reload",
    value: function reload(languages, namespaces, callback) {
      this.prepareLoading(languages, namespaces, {
        reload: true
      }, callback);
    }
  }, {
    key: "loadOne",
    value: function loadOne(name) {
      var _this5 = this;

      var prefix = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
      var s = name.split('|');
      var lng = s[0];
      var ns = s[1];
      this.read(lng, ns, 'read', undefined, undefined, function (err, data) {
        if (err) _this5.logger.warn("".concat(prefix, "loading namespace ").concat(ns, " for language ").concat(lng, " failed"), err);
        if (!err && data) _this5.logger.log("".concat(prefix, "loaded namespace ").concat(ns, " for language ").concat(lng), data);

        _this5.loaded(name, err, data);
      });
    }
  }, {
    key: "saveMissing",
    value: function saveMissing(languages, namespace, key, fallbackValue, isUpdate) {
      var options = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : {};

      if (this.services.utils && this.services.utils.hasLoadedNamespace && !this.services.utils.hasLoadedNamespace(namespace)) {
        this.logger.warn("did not save key \"".concat(key, "\" as the namespace \"").concat(namespace, "\" was not yet loaded"), 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
        return;
      }

      if (key === undefined || key === null || key === '') return;

      if (this.backend && this.backend.create) {
        this.backend.create(languages, namespace, key, fallbackValue, null, _objectSpread$3({}, options, {
          isUpdate: isUpdate
        }));
      }

      if (!languages || !languages[0]) return;
      this.store.addResource(languages[0], namespace, key, fallbackValue);
    }
  }]);

  return Connector;
}(EventEmitter);

function get() {
  return {
    debug: false,
    initImmediate: true,
    ns: ['translation'],
    defaultNS: ['translation'],
    fallbackLng: ['dev'],
    fallbackNS: false,
    whitelist: false,
    nonExplicitWhitelist: false,
    supportedLngs: false,
    nonExplicitSupportedLngs: false,
    load: 'all',
    preload: false,
    simplifyPluralSuffix: true,
    keySeparator: '.',
    nsSeparator: ':',
    pluralSeparator: '_',
    contextSeparator: '_',
    partialBundledLanguages: false,
    saveMissing: false,
    updateMissing: false,
    saveMissingTo: 'fallback',
    saveMissingPlurals: true,
    missingKeyHandler: false,
    missingInterpolationHandler: false,
    postProcess: false,
    postProcessPassResolved: false,
    returnNull: true,
    returnEmptyString: true,
    returnObjects: false,
    joinArrays: false,
    returnedObjectHandler: false,
    parseMissingKeyHandler: false,
    appendNamespaceToMissingKey: false,
    appendNamespaceToCIMode: false,
    overloadTranslationOptionHandler: function handle(args) {
      var ret = {};
      if (_typeof(args[1]) === 'object') ret = args[1];
      if (typeof args[1] === 'string') ret.defaultValue = args[1];
      if (typeof args[2] === 'string') ret.tDescription = args[2];

      if (_typeof(args[2]) === 'object' || _typeof(args[3]) === 'object') {
        var options = args[3] || args[2];
        Object.keys(options).forEach(function (key) {
          ret[key] = options[key];
        });
      }

      return ret;
    },
    interpolation: {
      escapeValue: true,
      format: function format(value, _format, lng, options) {
        return value;
      },
      prefix: '{{',
      suffix: '}}',
      formatSeparator: ',',
      unescapePrefix: '-',
      nestingPrefix: '$t(',
      nestingSuffix: ')',
      nestingOptionsSeparator: ',',
      maxReplaces: 1000,
      skipOnVariables: false
    }
  };
}
function transformOptions(options) {
  if (typeof options.ns === 'string') options.ns = [options.ns];
  if (typeof options.fallbackLng === 'string') options.fallbackLng = [options.fallbackLng];
  if (typeof options.fallbackNS === 'string') options.fallbackNS = [options.fallbackNS];

  if (options.whitelist) {
    if (options.whitelist && options.whitelist.indexOf('cimode') < 0) {
      options.whitelist = options.whitelist.concat(['cimode']);
    }

    options.supportedLngs = options.whitelist;
  }

  if (options.nonExplicitWhitelist) {
    options.nonExplicitSupportedLngs = options.nonExplicitWhitelist;
  }

  if (options.supportedLngs && options.supportedLngs.indexOf('cimode') < 0) {
    options.supportedLngs = options.supportedLngs.concat(['cimode']);
  }

  return options;
}

function noop() {}

var I18n = function (_EventEmitter) {
  _inherits(I18n, _EventEmitter);

  function I18n() {
    var _this;

    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var callback = arguments.length > 1 ? arguments[1] : undefined;

    _classCallCheck$1(this, I18n);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(I18n).call(this));

    if (isIE10) {
      EventEmitter.call(_assertThisInitialized(_this));
    }

    _this.options = transformOptions(options);
    _this.services = {};
    _this.logger = baseLogger;
    _this.modules = {
      external: []
    };

    if (callback && !_this.isInitialized && !options.isClone) {
      if (!_this.options.initImmediate) {
        _this.init(options, callback);

        return _possibleConstructorReturn(_this, _assertThisInitialized(_this));
      }

      setTimeout(function () {
        _this.init(options, callback);
      }, 0);
    }

    return _this;
  }

  _createClass$1(I18n, [{
    key: "init",
    value: function init() {
      var _this2 = this;

      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var callback = arguments.length > 1 ? arguments[1] : undefined;

      if (typeof options === 'function') {
        callback = options;
        options = {};
      }

      if (options.whitelist && !options.supportedLngs) {
        this.logger.deprecate('whitelist', 'option "whitelist" will be renamed to "supportedLngs" in the next major - please make sure to rename this option asap.');
      }

      if (options.nonExplicitWhitelist && !options.nonExplicitSupportedLngs) {
        this.logger.deprecate('whitelist', 'options "nonExplicitWhitelist" will be renamed to "nonExplicitSupportedLngs" in the next major - please make sure to rename this option asap.');
      }

      this.options = _objectSpread$3({}, get(), this.options, transformOptions(options));
      this.format = this.options.interpolation.format;
      if (!callback) callback = noop;

      function createClassOnDemand(ClassOrObject) {
        if (!ClassOrObject) return null;
        if (typeof ClassOrObject === 'function') return new ClassOrObject();
        return ClassOrObject;
      }

      if (!this.options.isClone) {
        if (this.modules.logger) {
          baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
        } else {
          baseLogger.init(null, this.options);
        }

        var lu = new LanguageUtil(this.options);
        this.store = new ResourceStore(this.options.resources, this.options);
        var s = this.services;
        s.logger = baseLogger;
        s.resourceStore = this.store;
        s.languageUtils = lu;
        s.pluralResolver = new PluralResolver(lu, {
          prepend: this.options.pluralSeparator,
          compatibilityJSON: this.options.compatibilityJSON,
          simplifyPluralSuffix: this.options.simplifyPluralSuffix
        });
        s.interpolator = new Interpolator(this.options);
        s.utils = {
          hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
        };
        s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
        s.backendConnector.on('*', function (event) {
          for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            args[_key - 1] = arguments[_key];
          }

          _this2.emit.apply(_this2, [event].concat(args));
        });

        if (this.modules.languageDetector) {
          s.languageDetector = createClassOnDemand(this.modules.languageDetector);
          s.languageDetector.init(s, this.options.detection, this.options);
        }

        if (this.modules.i18nFormat) {
          s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
          if (s.i18nFormat.init) s.i18nFormat.init(this);
        }

        this.translator = new Translator(this.services, this.options);
        this.translator.on('*', function (event) {
          for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
            args[_key2 - 1] = arguments[_key2];
          }

          _this2.emit.apply(_this2, [event].concat(args));
        });
        this.modules.external.forEach(function (m) {
          if (m.init) m.init(_this2);
        });
      }

      if (!this.modules.languageDetector && !this.options.lng) {
        this.logger.warn('init: no languageDetector is used and no lng is defined');
      }

      var storeApi = ['getResource', 'hasResourceBundle', 'getResourceBundle', 'getDataByLanguage'];
      storeApi.forEach(function (fcName) {
        _this2[fcName] = function () {
          var _this2$store;

          return (_this2$store = _this2.store)[fcName].apply(_this2$store, arguments);
        };
      });
      var storeApiChained = ['addResource', 'addResources', 'addResourceBundle', 'removeResourceBundle'];
      storeApiChained.forEach(function (fcName) {
        _this2[fcName] = function () {
          var _this2$store2;

          (_this2$store2 = _this2.store)[fcName].apply(_this2$store2, arguments);

          return _this2;
        };
      });
      var deferred = defer();

      var load = function load() {
        _this2.changeLanguage(_this2.options.lng, function (err, t) {
          _this2.isInitialized = true;

          _this2.logger.log('initialized', _this2.options);

          _this2.emit('initialized', _this2.options);

          deferred.resolve(t);
          callback(err, t);
        });
      };

      if (this.options.resources || !this.options.initImmediate) {
        load();
      } else {
        setTimeout(load, 0);
      }

      return deferred;
    }
  }, {
    key: "loadResources",
    value: function loadResources(language) {
      var _this3 = this;

      var callback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : noop;
      var usedCallback = callback;
      var usedLng = typeof language === 'string' ? language : this.language;
      if (typeof language === 'function') usedCallback = language;

      if (!this.options.resources || this.options.partialBundledLanguages) {
        if (usedLng && usedLng.toLowerCase() === 'cimode') return usedCallback();
        var toLoad = [];

        var append = function append(lng) {
          if (!lng) return;

          var lngs = _this3.services.languageUtils.toResolveHierarchy(lng);

          lngs.forEach(function (l) {
            if (toLoad.indexOf(l) < 0) toLoad.push(l);
          });
        };

        if (!usedLng) {
          var fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
          fallbacks.forEach(function (l) {
            return append(l);
          });
        } else {
          append(usedLng);
        }

        if (this.options.preload) {
          this.options.preload.forEach(function (l) {
            return append(l);
          });
        }

        this.services.backendConnector.load(toLoad, this.options.ns, usedCallback);
      } else {
        usedCallback(null);
      }
    }
  }, {
    key: "reloadResources",
    value: function reloadResources(lngs, ns, callback) {
      var deferred = defer();
      if (!lngs) lngs = this.languages;
      if (!ns) ns = this.options.ns;
      if (!callback) callback = noop;
      this.services.backendConnector.reload(lngs, ns, function (err) {
        deferred.resolve();
        callback(err);
      });
      return deferred;
    }
  }, {
    key: "use",
    value: function use(module) {
      if (!module) throw new Error('You are passing an undefined module! Please check the object you are passing to i18next.use()');
      if (!module.type) throw new Error('You are passing a wrong module! Please check the object you are passing to i18next.use()');

      if (module.type === 'backend') {
        this.modules.backend = module;
      }

      if (module.type === 'logger' || module.log && module.warn && module.error) {
        this.modules.logger = module;
      }

      if (module.type === 'languageDetector') {
        this.modules.languageDetector = module;
      }

      if (module.type === 'i18nFormat') {
        this.modules.i18nFormat = module;
      }

      if (module.type === 'postProcessor') {
        postProcessor.addPostProcessor(module);
      }

      if (module.type === '3rdParty') {
        this.modules.external.push(module);
      }

      return this;
    }
  }, {
    key: "changeLanguage",
    value: function changeLanguage(lng, callback) {
      var _this4 = this;

      this.isLanguageChangingTo = lng;
      var deferred = defer();
      this.emit('languageChanging', lng);

      var done = function done(err, l) {
        if (l) {
          _this4.language = l;
          _this4.languages = _this4.services.languageUtils.toResolveHierarchy(l);

          _this4.translator.changeLanguage(l);

          _this4.isLanguageChangingTo = undefined;

          _this4.emit('languageChanged', l);

          _this4.logger.log('languageChanged', l);
        } else {
          _this4.isLanguageChangingTo = undefined;
        }

        deferred.resolve(function () {
          return _this4.t.apply(_this4, arguments);
        });
        if (callback) callback(err, function () {
          return _this4.t.apply(_this4, arguments);
        });
      };

      var setLng = function setLng(lngs) {
        var l = typeof lngs === 'string' ? lngs : _this4.services.languageUtils.getBestMatchFromCodes(lngs);

        if (l) {
          if (!_this4.language) {
            _this4.language = l;
            _this4.languages = _this4.services.languageUtils.toResolveHierarchy(l);
          }

          if (!_this4.translator.language) _this4.translator.changeLanguage(l);
          if (_this4.services.languageDetector) _this4.services.languageDetector.cacheUserLanguage(l);
        }

        _this4.loadResources(l, function (err) {
          done(err, l);
        });
      };

      if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
        setLng(this.services.languageDetector.detect());
      } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
        this.services.languageDetector.detect(setLng);
      } else {
        setLng(lng);
      }

      return deferred;
    }
  }, {
    key: "getFixedT",
    value: function getFixedT(lng, ns) {
      var _this5 = this;

      var fixedT = function fixedT(key, opts) {
        var options;

        if (_typeof(opts) !== 'object') {
          for (var _len3 = arguments.length, rest = new Array(_len3 > 2 ? _len3 - 2 : 0), _key3 = 2; _key3 < _len3; _key3++) {
            rest[_key3 - 2] = arguments[_key3];
          }

          options = _this5.options.overloadTranslationOptionHandler([key, opts].concat(rest));
        } else {
          options = _objectSpread$3({}, opts);
        }

        options.lng = options.lng || fixedT.lng;
        options.lngs = options.lngs || fixedT.lngs;
        options.ns = options.ns || fixedT.ns;
        return _this5.t(key, options);
      };

      if (typeof lng === 'string') {
        fixedT.lng = lng;
      } else {
        fixedT.lngs = lng;
      }

      fixedT.ns = ns;
      return fixedT;
    }
  }, {
    key: "t",
    value: function t() {
      var _this$translator;

      return this.translator && (_this$translator = this.translator).translate.apply(_this$translator, arguments);
    }
  }, {
    key: "exists",
    value: function exists() {
      var _this$translator2;

      return this.translator && (_this$translator2 = this.translator).exists.apply(_this$translator2, arguments);
    }
  }, {
    key: "setDefaultNamespace",
    value: function setDefaultNamespace(ns) {
      this.options.defaultNS = ns;
    }
  }, {
    key: "hasLoadedNamespace",
    value: function hasLoadedNamespace(ns) {
      var _this6 = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (!this.isInitialized) {
        this.logger.warn('hasLoadedNamespace: i18next was not initialized', this.languages);
        return false;
      }

      if (!this.languages || !this.languages.length) {
        this.logger.warn('hasLoadedNamespace: i18n.languages were undefined or empty', this.languages);
        return false;
      }

      var lng = this.languages[0];
      var fallbackLng = this.options ? this.options.fallbackLng : false;
      var lastLng = this.languages[this.languages.length - 1];
      if (lng.toLowerCase() === 'cimode') return true;

      var loadNotPending = function loadNotPending(l, n) {
        var loadState = _this6.services.backendConnector.state["".concat(l, "|").concat(n)];

        return loadState === -1 || loadState === 2;
      };

      if (options.precheck) {
        var preResult = options.precheck(this, loadNotPending);
        if (preResult !== undefined) return preResult;
      }

      if (this.hasResourceBundle(lng, ns)) return true;
      if (!this.services.backendConnector.backend) return true;
      if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
      return false;
    }
  }, {
    key: "loadNamespaces",
    value: function loadNamespaces(ns, callback) {
      var _this7 = this;

      var deferred = defer();

      if (!this.options.ns) {
        callback && callback();
        return Promise.resolve();
      }

      if (typeof ns === 'string') ns = [ns];
      ns.forEach(function (n) {
        if (_this7.options.ns.indexOf(n) < 0) _this7.options.ns.push(n);
      });
      this.loadResources(function (err) {
        deferred.resolve();
        if (callback) callback(err);
      });
      return deferred;
    }
  }, {
    key: "loadLanguages",
    value: function loadLanguages(lngs, callback) {
      var deferred = defer();
      if (typeof lngs === 'string') lngs = [lngs];
      var preloaded = this.options.preload || [];
      var newLngs = lngs.filter(function (lng) {
        return preloaded.indexOf(lng) < 0;
      });

      if (!newLngs.length) {
        if (callback) callback();
        return Promise.resolve();
      }

      this.options.preload = preloaded.concat(newLngs);
      this.loadResources(function (err) {
        deferred.resolve();
        if (callback) callback(err);
      });
      return deferred;
    }
  }, {
    key: "dir",
    value: function dir(lng) {
      if (!lng) lng = this.languages && this.languages.length > 0 ? this.languages[0] : this.language;
      if (!lng) return 'rtl';
      var rtlLngs = ['ar', 'shu', 'sqr', 'ssh', 'xaa', 'yhd', 'yud', 'aao', 'abh', 'abv', 'acm', 'acq', 'acw', 'acx', 'acy', 'adf', 'ads', 'aeb', 'aec', 'afb', 'ajp', 'apc', 'apd', 'arb', 'arq', 'ars', 'ary', 'arz', 'auz', 'avl', 'ayh', 'ayl', 'ayn', 'ayp', 'bbz', 'pga', 'he', 'iw', 'ps', 'pbt', 'pbu', 'pst', 'prp', 'prd', 'ug', 'ur', 'ydd', 'yds', 'yih', 'ji', 'yi', 'hbo', 'men', 'xmn', 'fa', 'jpr', 'peo', 'pes', 'prs', 'dv', 'sam'];
      return rtlLngs.indexOf(this.services.languageUtils.getLanguagePartFromCode(lng)) >= 0 ? 'rtl' : 'ltr';
    }
  }, {
    key: "createInstance",
    value: function createInstance() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var callback = arguments.length > 1 ? arguments[1] : undefined;
      return new I18n(options, callback);
    }
  }, {
    key: "cloneInstance",
    value: function cloneInstance() {
      var _this8 = this;

      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var callback = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : noop;

      var mergedOptions = _objectSpread$3({}, this.options, options, {
        isClone: true
      });

      var clone = new I18n(mergedOptions);
      var membersToCopy = ['store', 'services', 'language'];
      membersToCopy.forEach(function (m) {
        clone[m] = _this8[m];
      });
      clone.services = _objectSpread$3({}, this.services);
      clone.services.utils = {
        hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
      };
      clone.translator = new Translator(clone.services, clone.options);
      clone.translator.on('*', function (event) {
        for (var _len4 = arguments.length, args = new Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
          args[_key4 - 1] = arguments[_key4];
        }

        clone.emit.apply(clone, [event].concat(args));
      });
      clone.init(mergedOptions, callback);
      clone.translator.options = clone.options;
      clone.translator.backendConnector.services.utils = {
        hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
      };
      return clone;
    }
  }]);

  return I18n;
}(EventEmitter);

var i18next = new I18n();

var en = {
	"translation" : {
		"generic" : {
			"button" : {
				"results" : "Results",
				"continue" : "Continue",
				"okay" : "Next",
				"view" : "View",
				"update" : "Update",
				"start" : "Start",
				"review" : "Review Answers"
			},
			"footer" : {
				"progress" : {
					"of" : "of",
					"answered" : "answered"
				}
			}
		},
		"language" : {
			"change" : "You can change your language anytime under settings",
			"german" : "German",
			"english" : "English",
			"choose" : "Choose your language"
		},
		"survey" : {
			"screen_answers" : {
				"title" : "Review your answers",
				"description_before_submit" : "Here you can review your answers before submitting them. You're always welcome to change your mind before doing so.",
				"description_after_submit" : "All answers have been submitted",
				"description_not_submitted" : "Expired and not submitted"
			},
			"screen_active" : {
				"how_many_answered" : "<1>{{answered_amount}}</1> of <2>{{total_amount}}</2> answered"
			},
			"screen_legal" : {
				"title" : "Important"
			},
			"button" : {
				"submit" : "Submit results",
				"try_again" : "Try again",
				"disagree" : "Go back",
				"agree" : "Agree & Submit",
				"subscribe" : "Subscribe to updates",
				"finalize" : "Next step",
				"review" : "Review my answers",
				"home" : "Back to home",
				"edit" : "Edit your answers"
			},
			"screen_submitted" : {
				"answers_submited" : "Your answers have been submitted!",
				"thank_you" : "Thank you for taking part in this.\nJust a reminder: Everything you've submitted will be securely transferred and published so that you always remain anonymous."
			},
			"screen_completed" : {
				"thank_you" : "Thank you for responding!"
			},
			"error" : {
				"title" : "Oops! An error occured.",
				"message" : "Thank you for taking part in the survey. Unfortunately an error occurred while submitting your answers. Please try again later."
			}
		},
		"analytics" : {
			"alert" : {
				"yes_option" : "Yes",
				"header" : "Help us improve the app",
				"description" : "App crash analytics help us understand when something goes wrong and sends anonymous reports to us so we can deliver a better app in future versions.",
				"no_option" : "No thanks"
			},
			"preferences" : {
				"action" : "Enable Analytics",
				"description" : "Crash Reporting analytics help us fix bugs and improve the app. This data is collected in accordance to our Data Collection policy and you can opt out of it anytime."
			}
		},
		"onboarding" : {
			"screen_03" : {
				"main_message_02" : "Aggregated results are released after the survey period has ended on the website of our partners in secure data collection for better decisions as a society in transition.",
				"button" : {
					"continue" : "Who is polypoly?"
				}
			},
			"screen_01" : {
				"title" : "#TellYourPod",
				"button" : {
					"continue" : "How it works"
				},
				"main_message" : "The polyPod is a secure way for you to share data. It delivers surveys that cover lots of different topics. The questions and answers are designed to fully respect your privacy."
			},
			"screen_04" : {
				"message" : "<1>polypoly</1> is on a mission to make data more secure and personal. Our solutions are Private by Design and user-centric in the most basic sense.\nThe <3>polyPod</3> is polypoly's core product.",
				"button" : {
					"continue" : "Continue"
				}
			},
			"screen_02" : {
				"button" : {
					"continue" : "Is this safe?"
				},
				"main_message" : "New surveys will be released every month and should take around five minutes of your time.\nMore participants creates a better picture about what the European community cares about."
			},
			"collected_data" : "What data is collected?",
			"analytics" : {
				"title" : "Help us improve the app",
				"details" : "App crash analytics help us understand when something goes wrong and sends anonymous reports to us, helping us improve the app."
			}
		},
		"general" : {
			"none-above" : "None of the above",
			"yes" : "Yes",
			"choose-one" : "Choose one (1):",
			"choose-seat" : "Move the scale to reflect your opinion:",
			"completely" : "Completely",
			"no" : "No",
			"text-input-shadow-text" : "Type your answer here",
			"choose-one-or-more" : "Choose one or more from the following list:",
			"very" : "Very",
			"not-at-all" : "Not at all",
			"select-all-apply" : "Please select all that apply:",
			"i-dont-know" : "I don't know",
			"enter-answer-below" : "Enter your answer below:",
			"choose-up-to" : "Choose up to {{max_selections}} answers from the following list:"
		},
		"intro" : {
			"author" : "Author",
			"expires" : "Expires",
			"button" : {
				"continue" : "Continue Survey",
				"results" : "Check Results",
				"view" : "View Answers"
			},
			"survey_by" : "Survey by",
			"published" : "Published",
			"submitted" : "Submitted"
		},
		"settings" : {
			"section" : {
				"developer" : "Developer",
				"feedback" : "Feedback",
				"preferences" : "Preferences",
				"notices" : "Notices"
			},
			"title" : "Settings",
			"items" : {
				"send_us_feedback" : "Send us feedback",
				"languages" : "Languages",
				"all_screens" : "All Screens",
				"analytics" : "Analytics",
				"introduction" : "Restart introduction",
				"feedback" : "Send us feedback",
				"data_collection" : "Data Protection",
				"terms_conditions" : "Terms & Conditions",
				"imprint" : "Imprint",
				"about" : "About"
			},
			"back_to_settings" : "Back to settings"
		},
		"home" : {
			"tabs" : {
				"submitted" : "Submitted",
				"expired" : "Expired",
				"featured" : "Featured"
			},
			"notification" : {
				"title" : "Check for new surveys"
			},
			"expired_answers" : {
				"not_submitted" : "Expired and not submitted"
			},
			"message" : "Survey submissions will be closed on",
			"current_answers" : {
				"of" : "of",
				"answered" : "answered",
				"questions" : "Questions"
			},
			"no_surveys" : "No surveys available now. Check back again soon!",
			"submitted_answers" : {
				"closing_message" : "Survey closes on {{closingDate}}",
				"thank_you" : "Thank you for your reponse!",
				"results_available" : "Results available now!"
			}
		},
		"validation" : {
			"only-one-word" : "Please enter only one word"
		},
		"loading" : {
			"by" : "by"
		},
		"imprint" : {
			"description" : "polypoly GmbH\nThorsten Dittmar\nRichardstr. 85/86\n12043 Berlin\nhello@polypoly.eu\n\n+49 30 62934054\nVAT-ID: DE324790734"
		},
		"test" : {
			"test-key1" : "The test key was successfully translated",
			"test-v2" : "Test-Value2",
			"test-v1" : "Test-Value1"
		}
	}
};

var de = {
	"translation" : {
		"generic" : {
			"button" : {
				"results" : "Resultate",
				"continue" : "Fortsetzen",
				"okay" : "Weiter",
				"view" : "Ansicht",
				"update" : "Aktualisieren",
				"start" : "Start",
				"review" : "Übersicht"
			},
			"footer" : {
				"progress" : {
					"of" : "von",
					"answered" : "beantwortet"
				}
			}
		},
		"language" : {
			"change" : "Du kannst in den Einstellungen die Anzeigesprache jederzeit ändern",
			"german" : "Deutsch",
			"english" : "Englisch",
			"choose" : "Wähle deine Anzeigesprache"
		},
		"survey" : {
			"screen_answers" : {
				"title" : "Überprüfe deine Antworten",
				"description_before_submit" : "Hier kannst Du noch einmal alle Antworten durchsehen, bevor Du sie übermittelst. Du kannst Dich dabei auch natürlich bei allen Antworten noch einmal umentscheiden.",
				"description_after_submit" : "Alle Antworten wurden übermittelt",
				"description_not_submitted" : "Abgelaufen und nicht versandt"
			},
			"screen_active" : {
				"how_many_answered" : "<1>{{answered_amount}}</1> von <2>{{total_amount}}</2> beantwortet"
			},
			"screen_legal" : {
				"title" : "Wichtige Hinweise"
			},
			"button" : {
				"submit" : "Antworten übermitteln",
				"try_again" : "Versuche es nochmal",
				"disagree" : "Zurück",
				"agree" : "Zustimmen & absenden",
				"subscribe" : "Updates abonnieren",
				"finalize" : "Nächster Schritt",
				"review" : "Antworten überprüfen",
				"home" : "Zurück zum Startbildschirm",
				"edit" : "Bearbeite deine Antworten"
			},
			"screen_submitted" : {
				"answers_submited" : "Deine Antworten wurden übermittelt!",
				"thank_you" : "Vielen Dank für Deine Teilnahme.\nNur zur Erinnerung: Alles, was Du übermittelt hast, wird sicher verschlüsselt übertragen und nur so Veröffentlicht, dass Du auf jeden Fall immer anonym bleibst."
			},
			"screen_completed" : {
				"thank_you" : "Vielen Dank für die Antworten!"
			},
			"error" : {
				"title" : "Hoppla! Ein Fehler ist aufgetreten.",
				"message" : "Vielen Dank, dass du dich an der Umfrage beteiligt hast. Leider ist bei der Übermittlung deiner Antworten ein Fehler aufgetreten. Bitte versuche es später noch einmal."
			}
		},
		"analytics" : {
			"alert" : {
				"yes_option" : "Ja",
				"header" : "Hilf uns, die App zu verbessern",
				"description" : "Absturzberichte helfen uns zu erkennen, ob etwas schief gelaufen ist. Dafür sendet die App in diesem Fall anonymisierte technische Informationen an unsere Server.",
				"no_option" : "Nein danke"
			},
			"preferences" : {
				"action" : "Analytik aktivieren",
				"description" : "Absturzanalysen helfen uns, Fehler zu beheben und die Anwendung zu verbessern. Diese Daten werden in Übereinstimmung mit unseren Richtlinien zur Datenerfassung erfasst. Du kannst sie jederzeit abbestellen."
			}
		},
		"onboarding" : {
			"screen_03" : {
				"main_message_02" : "Die Ergebnisse werden nach Ablauf des Erhebungszeitraums auf der Website unserer Partner veröffentlicht.",
				"button" : {
					"continue" : "Wer ist polypoly?"
				}
			},
			"screen_01" : {
				"title" : "#TellYourPod",
				"button" : {
					"continue" : "Wie funktioniert das?"
				},
				"main_message" : "Der polyPod ist ein sicherer Weg um Daten zu teilen. Regelmäßig erscheinen dazu neue Umfragen zu vielen verschiedenen Themen. Sowohl die Fragen als auch die möglichen Antworten sind sorgfältig zusammengestellt, um Deine Privatsphäre zu schützen."
			},
			"screen_04" : {
				"message" : "<1>polypoly</1> hat die Mission persönliche Daten sicher zu machen. Unsere Lösungen beinhalten Datenschutz by Design und stellen Dich als Nutzer in den Mittelpunkt.\nDer <3>polyPod</3> ist polypolys Kernprodukt.",
				"button" : {
					"continue" : "Weiter"
				}
			},
			"screen_02" : {
				"button" : {
					"continue" : "Sind meine Daten sicher?"
				},
				"main_message" : "Jeden Monat werden neue Umfragen veröffentlicht, die nur etwa fünf Minuten deiner Zeit in Anspruch nehmen sollten.\nJe mehr Menschen teilnehmen, desto klarer wird, welche Themen der europäischen Gemeinschaft auf dem Herzen liegen."
			},
			"collected_data" : "Welche Daten werden erhoben?",
			"analytics" : {
				"title" : "Hilf uns, die App zu verbessern",
				"details" : "Die Absturzanalyse der App hilft uns zu verstehen, wenn etwas schief geht. Sie sendet anonyme Berichte an uns, die uns helfen, die App zu verbessern."
			}
		},
		"general" : {
			"none-above" : "Keines davon",
			"yes" : "Ja",
			"choose-one" : "Wähle eine (1) Option:",
			"choose-seat" : "Bitte gib an, wo du dich auf dieser Skala wiederfindest:",
			"completely" : "Vollständiges Vertrauen",
			"no" : "Nein",
			"text-input-shadow-text" : "Gib hier deine Antwort ein",
			"choose-one-or-more" : "Bitte einen oder mehrere Einträge aus der Liste auswählen:",
			"very" : "Sehr",
			"not-at-all" : "Gar nicht",
			"select-all-apply" : "Bitte alles Zutreffende auswählen:",
			"i-dont-know" : "Ich habe keine Ahnung",
			"enter-answer-below" : "Bitte trage hier deine Antwort ein:",
			"choose-up-to" : "Bitte bis zu {{max_selections}} Antworten aus der Liste auswählen:"
		},
		"intro" : {
			"author" : "Autor",
			"expires" : "Läuft ab",
			"button" : {
				"continue" : "Umfrage fortführen",
				"results" : "Ergebnisse ansehen",
				"view" : "Antworten ansehen"
			},
			"survey_by" : "Umfrage von",
			"published" : "Veröffentlicht",
			"submitted" : "Versandt"
		},
		"settings" : {
			"section" : {
				"developer" : "Entwickler",
				"feedback" : "Feedback",
				"preferences" : "Allgemein",
				"notices" : "Hinweise"
			},
			"title" : "Einstellungen",
			"items" : {
				"send_us_feedback" : "Sende uns Feedback",
				"languages" : "Sprachen",
				"all_screens" : "Alle Screens",
				"analytics" : "Analytik",
				"introduction" : "Einführung wiederholen",
				"feedback" : "Sende uns Feedback",
				"data_collection" : "Datenschutz",
				"terms_conditions" : "Bedingungen und Konditionen",
				"imprint" : "Impressum",
				"about" : "Über uns"
			},
			"back_to_settings" : "Zurück zu den Einstellungen"
		},
		"home" : {
			"tabs" : {
				"submitted" : "Übermittelt",
				"expired" : "Abgelaufen",
				"featured" : "Featured"
			},
			"notification" : {
				"title" : "Prüfe auf neue Umfragen"
			},
			"expired_answers" : {
				"not_submitted" : "Abgelaufen und nicht versandt"
			},
			"message" : "Der Einsendeschluss ist am",
			"current_answers" : {
				"of" : "von",
				"answered" : "beantwortet",
				"questions" : "Fragen"
			},
			"no_surveys" : "Derzeit sind keine Umfragen verfügbar. Schaue später noch einmal nach!",
			"submitted_answers" : {
				"closing_message" : "Diese Umfrage wird am {{closingDate}} geschlossen.",
				"thank_you" : "Danke, dass du an der Umfrage teilgenommen hast!",
				"results_available" : "Resultate jetzt verfügbar"
			}
		},
		"validation" : {
			"only-one-word" : "Bitte gib nur ein Wort ein"
		},
		"loading" : {
			"by" : "von"
		},
		"imprint" : {
			"description" : "polypoly GmbH\nThorsten Dittmar\nRichardstr. 85/86\n12043 Berlin\nhello@polypoly.eu\n\n+49 30 62934054\nUSt-ID: DE324790734"
		},
		"test" : {
			"test-key1" : "Der Testschlüssel wurde erfolgreich übersetzt",
			"test-v2" : "Testwert2",
			"test-v1" : "Testwert1"
		}
	}
};

var resources = {
  en: en,
  de: de,
};

i18next
  .use(initReactI18next) // passes i18n down to react-i18next
  .init({
    debug: false,
    resources: resources,
    lng: 'en',
    fallbackLng: 'en',

    interpolation: {
      escapeValue: false,
    },
  });

// A PpQuestion is a single question in a questionnaire.
//
// The different types of questions (binary, text, single / multiple choice) are defined by subclasses.
//
// - Questions may be conditional on previous answers, see the activationCondition.
// - The explanation is a short 1 line hint on how to interpret / answer the question.
//

class PpQuestion extends PpQObject {
  constructor(description) {
    super();
    this._id = nextGlobalId();
    this._index = null;
    this._description = description;
    this._activationCondition = new PpTrueCondition();
    this._explanation = '';
    this._questionnaire = null;
  }

  get id() {
    return this._id;
  }

  get index() {
    return this._index;
  }

  set index(index) {
    this._index = index;
  }

  get questionnaire() {
    return this._questionnaire;
  }

  set questionnaire(questionnaire) {
    this._questionnaire = questionnaire;
  }

  get question_language() {
    return this.questionnaire.question_language;
  }

  activationCondition() {
    return this._activationCondition;
  }

  setActivationCondition(condition) {
    this._activationCondition = condition;
    condition.question = this;
    return this;
  }

  description() {
    return i18next.t(this._description);
  }

  setDescription(a_string) {
    this._description = a_string;
    return this;
  }

  explanation() {
    return i18next.t(this._explanation);
  }

  setexplanation(explanation) {
    this._explanation = explanation;
    return this;
  }

  isActive() {
    return this._activationCondition.isActive();
  }

  isFirst() {
    return this.index === 1;
  }

  screen() {
    throw Error('subclass responsibility');
  }

  isAnswered() {
    throw Error('subclass responsibility');
  }

  value() {
    throw Error('subclass responsibility');
  }

  toJSON() {
    let jsonObject = super.toJSON();
    if (this._questionnaire != null) {
      jsonObject._questionnaire = this._questionnaire.id;
    }
    return jsonObject;
  }

  postJSONLoad(questionnaire) {
    super.postJSONLoad();
    if (this._questionnaire != null) {
      assert(questionnaire.id == this._questionnaire);
      this._questionnaire = this.questionnaire;
    }
    this._activationCondition.postJSONLoad(questionnaire);
  }

  // Update the receiver based on the supplied answer (JSON object)
  loadAnswer(answer) {
    throw Error('subclass responsibility');
  }
}

// PpChoice repesents a single option within a single- or multiple-
// choice question.
//
// Instance Variables:
//
// - id uniquely identifies the question with the global scope.
//   See PpID.js for a description of global UID management.
// - question holds the question to which this choice belongs.
//   This is cleared and reloaded as part of
//   serialisation / deserialisation.
// - index is the choice number in the question
// - enabled indicates whether the corresponding UI element should
//   be enabled or not.  It is managed by the question.
//
class PpChoice extends PpQObject {
  constructor() {
    super();
    this._id = nextGlobalId();
    this._question = null;
    this._index = null;
    this._enabled = true;
  }

  get id() {
    return this._id;
  }

  get question() {
    return this._question;
  }

  set question(question) {
    this._question = question;
  }

  get index() {
    return this._index;
  }

  set index(index) {
    this._index = index;
  }

  get enabled() {
    return this._enabled;
  }

  set enabled(enabled) {
    this._enabled = enabled;
  }

  // Set the selection state of the receiver
  selected(a_boolean) {
    if (a_boolean) {
      this.beSelected();
    } else {
      this.beNotSelected();
    }
  }

  beSelected() {
    this._question.selectChoice(this);
    this._question.updateEnabled();
  }

  beNotSelected() {
    this._question.updateEnabled();
  }

  isSelected() {
    return false;
  }

  value() {
    throw Error('subclass responsibility');
  }

  toJSON() {
    let jsonObject = super.toJSON();
    // Don't save the question, it will be restored on load
    jsonObject._question = null;
    return jsonObject;
  }

  postJSONLoad(question) {
    super.postJSONLoad();
    this._question = question;
  }
}

class PpTextualChoice extends PpChoice {
  constructor(description) {
    super();
    this.is_selected = false;
    this._description = description;
  }

  beSelected() {
    this.is_selected = true;
    super.beSelected();
    return this;
  }

  beNotSelected() {
    this.is_selected = false;
    super.beNotSelected();
    return this;
  }

  description() {
    return this._description;
  }

  setDescription(a_string) {
    this._description = a_string;
    return this;
  }

  isSelected() {
    return this.is_selected;
  }

  value() {
    return i18next.t(this._description);
  }
}

//module.exports = PpTextualChoice;

class PpChoiceQuestion extends PpQuestion {
    constructor(description) {
        super(description);
        this._choices = [];
    }

    choices() {
        return this._choices;
    }

    selectChoice() {
        // Subclasses will override with required behaviour
    }

    // updateEnabled()
    //
    // The state of one or more of the receiver's choices have changed.
    // Update the other choices as required.
    // This will be overridden by subclasses if required.
    //
    updateEnabled() {
    }

    addTextualChoiceWithDescription(a_string) {
        let choice = new PpTextualChoice(a_string);

        this._choices[this._choices.length] = choice;
        choice.question = this;
        choice.index = this._choices.length - 1;

        return this;
    }

    postJSONLoad(questionnaire) {
        super.postJSONLoad(questionnaire);
        this._choices.forEach(choice => choice.question = this);
    }

    toString() {
        var result = this.constructor.name + '(';
        this.choices().forEach(choice => {
            result += choice.index + ': ' + choice.isSelected() + ', ';
        });
        result += ')';
        return result;
    }
}

//module.exports = PpChoiceQuestion;

//
// Multiple choice questions are those typically represented by
// check boxes, where the user can select or or more options.
//
// - max_selections_allowed is the maximum number of choices the
//   user can make for this question
// - Exclusion groups are defined below
//
// Exclusion Groups:
//
// Questions will often include a final option of "none of the above" or
// similar.  Exclusion Groups are a generalisation of this requirement that
// means that whenever a selection is made within a group, all choices outside
// that group are automatically deselected.
//
// Exclusion groups are repesented as a collection of groups, as an
// array of arrays.  Each group consists of the index of the member questions.
//

class PpMultipleChoiceQuestion extends PpChoiceQuestion {
  constructor(description) {
    super(description);
    this._max_selections_allowed = Infinity;
    this._exclusion_groups = [];
  }

  maxSelectionsAllowed() {
    if (this._max_selections_allowed == undefined ||
      this._max_selections_allowed == null) {
      return Infinity;
    } else {
      return this._max_selections_allowed;
    }
  }

  setMaxSelectionsAllowed(an_integer) {
    assert(an_integer > 1);
    this._max_selections_allowed = an_integer;
    return this;
  }

  get exclusion_groups() {
    return this._exclusion_groups;
  }

  set exclusion_groups(an_array) {
    this._exclusion_groups = an_array;
  }

  explanation() {
    if (this._explanation.length > 0) {
      return super.explanation();
    }
    if (this._max_selections_allowed == undefined ||
      this._max_selections_allowed == null ||
      this._max_selections_allowed == Infinity) {
      return i18next.t('general.choose-one-or-more');
    } else {
      return i18next.t('general.choose-up-to', {max_selections: this.maxSelectionsAllowed()});
    }
  }

  isAnswered() {
    return this.selectedChoices().length > 0;
  }

  value() {
    return this.selectedChoices().map(choice => choice.value());
  }

  screen() {
    return 'MultipleChoiceQuestion';
  }

  selectedChoices() {
    return this._choices.filter(item => item.isSelected());
  }

  selectedChoiceIds() {
    return this.selectedChoices().map(choice => choice.id);
  }

  // Answer the object to be stored in the answer json document.
  // This is the ids of selected choices.
  answer() {
    return this.selectedChoiceIds();
  }

  // The supplied choice has been selected.
  //
  // If the choice is part of an exclusion group, deselect all choices
  // that are part of other exclusion groups.
  //
  // If maxSelectionsAllowed has been reached, ensure that only the
  // selected choices are enabled.
  selectChoice(choice) {
    // Find the exclusion_group the choice is a member of
    let exclusion_group = this._exclusion_groups.find(
        group => group.find(index => index == choice.index) != undefined);
    // If none, no further action requried
    if (exclusion_group == undefined) {
      return;
    }
    // Deselect choices that are a member of other groups
    this._exclusion_groups.forEach(group => {
      if (group != exclusion_group) {
        group.forEach(choice_index => {
          if (this.choices()[choice_index].isSelected()) {
            this.choices()[choice_index].beNotSelected();
          }
        });
      }
    });
  }

  // updateEnabled()
  //
  // If maxSelectionsAllowed has been reached, ensure that only the
  // selected choices are enabled.
  //
  updateEnabled() {
    if (this.selectedChoices().length >= this.maxSelectionsAllowed()) {
      this.choices().forEach(choice => {
        choice.enabled = choice.isSelected();
      });
    } else {
      this.choices().forEach(choice => choice.enabled = true);
    }
  }

  // Update the receiver based on the supplied answer (JSON object)
  loadAnswer(answer) {
    assert(answer.questionId === this.id);
    this._choices.forEach(choice => choice.beNotSelected());
    answer.answer.forEach(value => {
      this._choices.find(choice => choice.id === value).beSelected();
    });
  }

  postJSONLoad(questionnaire) {
    super.postJSONLoad(questionnaire);
    if (this._max_selections_allowed == null) {
      this._max_selections_allowed = Infinity;
    }
  }

}

class PpSingleChoiceQuestion extends PpChoiceQuestion {
    constructor(description) {
        super(description);
        this._explanation = 'general.choose-one';
    }

    selectedChoice() {
        return this._choices.find(item => item.isSelected());
    }

    isAnswered() {
        return this.selectedChoice() != undefined;
    }

    value() {
        return this.selectedChoice().value();
    }

    screen() {
        return 'MultipleChoiceQuestion';
    }

    // Answer the object to be stored in the answer json document.
    // This is the ids of selected choices.
    answer() {
        if (this.isAnswered()) {
            return this.selectedChoice().id;
        } else {
            return null;
        }
    }

    // The supplied choice has been selected.
    //
    // Deselect all other choices
    //
    selectChoice(choice) {
        this.choices().forEach(each => {
            if (each !== choice) {
                each.beNotSelected();
            }
        });
    }

    // Update the receiver based on the supplied answer (JSON object)
    loadAnswer(answer) {
        assert(answer.questionId == this.id);
        this._choices.forEach(choice => choice.beNotSelected());
        if (answer.answer != null) {
            this._choices.find(choice => choice.id == answer.answer)
                .beSelected();
        }
    }

}

//module.exports = PpSingleChoiceQuestion;

class PpTextQuestion extends PpQuestion {
    constructor(description) {
        super(description);
        this._answer = null;
        this._explanation = 'general.enter-answer-below';
        this._max_length = null;
        this._multiline = false;
        this._number_of_lines = 1;
        this._one_word_validation = false;
    }

    get maxLength() {
        return this._max_length;
    }

    set maxLength(an_integer) {
        this._max_length = an_integer;
    }

    get multiline() {
        return this._multiline;
    }

    set multiline(a_boolean) {
        this._multiline = a_boolean;
    }

    get numberOfLines() {
        return this._number_of_lines;
    }

    set numberOfLines(an_integer) {
        this._number_of_lines = an_integer;
    }

    get oneWordValidation() {
        return this._one_word_validation;
    }

    set oneWordValidation(a_boolean) {
        this._one_word_validation = a_boolean;
    }

    isAnswered() {
        if (this._answer == undefined || this._answer == null) {
            return false;
        }
        return this._answer.length > 0;
    }

    answer() {
        return this._answer;
    }

    setAnswer(value) {
        if (this.maxLength != null && value.length > this.maxLength) {
            throw Error('Answer length too long: ' + value.length + ' > ' + this.maxLength);
        }
        this._answer = value;
        return this;
    }

    value() {
        if (this._answer == null) {
            return null;
        }
        return i18next.t(this._answer);
    }

    screen() {
        return 'TextQuestion';
    }

    // Update the receiver based on the supplied answer (JSON object)
    loadAnswer(answer) {
        assert(answer.questionId == this.id);
        this._answer = answer.answer;
    }

}

//module.exports = PpTextQuestion;

class PpDependOnMultipleChoice extends PpDependOnAnotherQuestion {
    constructor(dependent_question, choices) {
        super(dependent_question);
        this._choices = choices;
    }

    choices() {
        return this._choices;
    }

    setChoices(choices) {
        this._choices = choices;
        return this;
    }

    // Answer a boolean indicating whether the receiver is active,
    // i.e. all the choices have been selected.
    isActive() {
        return this._choices.find((choice) => !choice.isSelected()) == undefined;
    }

    toJSON() {
        let choices = [];
        // Save the index of the choices and reconstruct on deseralisation
        this._choices.forEach((choice, index) => {
            choices[index] = this._dependent_question.choices().indexOf(choice);
        });
        let jsonObject = super.toJSON();
        jsonObject._choices = choices;
        return jsonObject;
    }

    postJSONLoad(questionnaire) {
        super.postJSONLoad(questionnaire);
        let choices = [];
        // Reconstruct the choices
        this._choices.forEach((choiceIndex, index) => {
            choices[index] = this._dependent_question.choices()[choiceIndex];
        });
        this._choices = choices;
    }
}

//
// PpDependOnLanguage is used to activate or deactivate questions
// based on the question language of the questionnaire (which may 
// be different from the language the questionnaire is displayed in).
//
// The language tag is assumed to be in the format:
//
//      <languageCode>_<countryCode>
// e.g.
//      en_AU
//
// Comparisons are made by simply checking if the language 
// string begins with the specified language string, so specifying
// "en" will match all English language variants, while "en_AU" is 
// specific to Australian English.
//
// String encoding, e.g. "en_AU.UTF-8", is ignored.
//
// Instance variables:
//
// - _language_tags: The languages to match against.
//   The condition is active if any one of the tags matches.
//

class PpDependOnLanguage extends PpActivationCondition {
    constructor(language_tags) {
        super();
        this._language_tags = language_tags.map(x => x.toLowerCase());
    }

    get language_tags() {
        return this._language_tags;
    }

    set language_tags(tags) {
        this._language_tag = tags;
    }

    // Answer the language the questionnaire is presentated in.
    get question_language() {
        return this.question.question_language;
    }

    isActive() {
        let language = this.question_language.toLowerCase();
        return this._language_tags
            .find(tag => language.startsWith(tag)) != undefined;
    }
}

//

class PpRangeQuestion extends PpQuestion {
    constructor (description) {
        super(description);
        this._explanation = 'general.choose-seat';
        this._min = 0;
        this._max = 0;
        this._steps = null;
        this._labels = [];
        this._value = null;
    }

    screen() {
        return 'RangeQuestion';
    }

    get min() {
        return this._min;
    }

    set min(min) {
        this._min = min;
    }

    get max() {
        return this._max;
    }

    set max(max) {
        this._max = max;
    }

    get steps() {
        return this._steps;
    }

    set steps(steps) {
        this._steps = steps;
    }

    get labels() {
        return this._labels.map(label => i18next.t(label));
    }

    set labels(labels) {
        this._labels = labels;
    }

    get raw_labels() {
        return this._labels;
    }

    isAnswered() {
        return this._value != null;
    }

    values() {
        let values = [];
        let current = this.min;

        while (current < this.max) {
            values.push(current);
            current += this.steps;
        }        values.push(this.max);
        return values;
    }

    value() {
        return this._value;
    }

    setValue(value) {
        this._value = value;
    }

    // Update the receiver based on the supplied answer (JSON object)
    loadAnswer(answer) {
        assert(answer.questionId == this.id);
        this._value = answer.answer;
    }

}

//module.exports = PpRangeQuestion;

//

class PpCompoundActivationCondition extends PpActivationCondition {
    constructor(question) {
        super();
        this._children = [];
    }

    get children() {
        return this._children;
    }

    addChild(childCondition) {
        this._children[this._children.length] = childCondition;
        return this;
    }

    removeChild(childCondition) {
        let index = this._children.indexOf(childCondition);
        if (index < 0) {
            throw Error('Unable to find child to be removed');
        }
        this._children.splice(index, 1);
        return this;
    }
}

//

class PpAndActivationCondition extends PpCompoundActivationCondition {
    isActive() {
        return this.children.find((child) => !child.isActive()) == undefined
    }
}

//

class PpOrActivationCondition extends PpCompoundActivationCondition {
    isActive() {
        return this.children.find((child) => child.isActive()) != undefined
    }
}

//

class PpFalseCondition extends PpActivationCondition {

    isActive() {
        return false;
    }
}

//
// PpAuthor - store details about the author of the questionnaire
//
// - _name: Author's name
// - _link: URL to the author's home page
// - _description: A description of the author.  This should be a key in to 
//   the questionnaire translation files.
// - _logo: base64 encoded image
//
class PpAuthor extends PpQObject {
    constructor() {
      super();
      this._name = null;
      this._link = null;
      this._description = null;
      this._logo = null;
    }

    get name() {
        return this._name;
    }

    set name(name) {
        this._name = name;
    }

    get link() {
        return this._link;
    }

    set link(url) {
        this._link = url;
    }

    get description() {
        return this._description;
    }

    set description(description) {
        this._description = description;
    }

    get logo() {
        return this._logo;
    }

    set logo(base64String) {
        this._logo = base64String;
    }
}

class PpLegal extends PpQObject {
  constructor() {
    super();
    this._content = null;
    this._link = null;
  }

  get content() {
    return this._content;
  }

  set content(content) {
    this._content = content;
  }

  get link() {
    return this._link;
  }

  set link(url) {
    this._link = url;
  }
}

//
// PpTermsAndConditions - store details about the T&C of the questionnaire
//
// - _text: The text to be displayed.
// - _link: The primary link to the web page containing the T&C
//
class PpTermsAndConditions extends PpQObject {
    constructor() {
      super();
      this._link = null;
      this._text = null;
    }

    get link() {
        return this._link;
    }

    set link(url) {
        this._link = url;
    }

    get text() {
        return this._text;
    }

    set text(text) {
        this._text = text;
    }

}

//
// PpPrivacyPolicy - store details about the T&C of the questionnaire
//
// - _text: The text to be displayed.
// - _link: The primary link to the web page containing the T&C
//
class PpPrivacyPolicy extends PpQObject {
    constructor() {
      super();
      this._link = null;
      this._text = null;
    }

    get link() {
        return this._link;
    }

    set link(url) {
        this._link = url;
    }

    get text() {
        return this._text;
    }

    set text(text) {
        this._text = text;
    }

}

class PpQuestionFactory {
  textQuestion(description) {
    return new PpTextQuestion(description);
  }

  singleChoiceQuestion(description) {
    return new PpSingleChoiceQuestion(description);
  }

  multipleChoiceQuestion(description) {
    return new PpMultipleChoiceQuestion(description);
  }

  rangeQuestion(description) {
    return new PpRangeQuestion(description);
  }

  questionnaire() {
    return new PpQuestionnaire();
  }

  author() {
    return new PpAuthor();
  }

  legal() {
    return new PpLegal();
  }

  termsAndConditions() {
    return new PpTermsAndConditions();
  }

  privacyPolicy() {
    return new PpPrivacyPolicy();
  }

  dependOnSingleChoice(question, choice) {
    return new PpDependOnSingleChoice(question, choice);
  }

  dependOnMultipleChoice(question, choices) {
    return new PpDependOnMultipleChoice(question, choices);
  }

  dependOnLanguage(language_tags) {
    return new PpDependOnLanguage(language_tags);
  }

  andCondition() {
    return new PpAndActivationCondition();
  }

  orCondition() {
    return new PpOrActivationCondition();
  }

  trueCondition() {
    return new PpTrueCondition();
  }

  falseCondition() {
    return new PpFalseCondition();
  }
}

//module.exports = PpQuestionFactory;

class PpQuestionnaireLinkResult extends PpQObject {
  constructor() {
    super();
    this._url = null;
  }

  get url() {
    return this._url;
  }

  set url(newUrl) {
    this._url = newUrl;
  }
}

//

const KnownClasses = {
  PpActivationCondition: PpActivationCondition,
  PpDependOnSingleChoice: PpDependOnSingleChoice,
  PpQuestionnaire: PpQuestionnaire,
  PpMultipleChoiceQuestion: PpMultipleChoiceQuestion,
  PpSingleChoiceQuestion: PpSingleChoiceQuestion,
  PpChoice: PpChoice,
  PpTextQuestion: PpTextQuestion,
  PpChoiceQuestion: PpChoiceQuestion,
  PpQObject: PpQObject,
  PpTextualChoice: PpTextualChoice,
  PpDependOnAnotherQuestion: PpDependOnAnotherQuestion,
  PpTrueCondition: PpTrueCondition,
  PpQuestionFactory: PpQuestionFactory,
  PpDependOnMultipleChoice: PpDependOnMultipleChoice,
  PpQuestion: PpQuestion,
  PpRangeQuestion: PpRangeQuestion,
  PpQuestionnaireLinkResult: PpQuestionnaireLinkResult,
  PpAuthor: PpAuthor,
  PpLegal: PpLegal,
  PpTermsAndConditions: PpTermsAndConditions,
  PpPrivacyPolicy: PpPrivacyPolicy,
};

//
// Deserialise the suimport Pplied key / value pairs.
//
// Any value that has a __class__ object can create an instance of itself
// from 'the json object.
//
function PpQReplacer(key, value) {
  if (value != null && value.__class__) {
    return KnownClasses[value.__class__].fromJSON(value);
  }
  return value;
}

const API_HOME = "https://api.polypoly.tech/v2/";

const { polyOut } = window.pod;

async function downloadQuestionnaireData(questionnaireId) {
    const statusCheckEndpoint = API_HOME + "questionnaire/" + questionnaireId + "/content";
    return timeoutPromise(
        10000,
        polyOut
            .fetch(statusCheckEndpoint, {
                headers: {
                    "User-Agent": userAgent(),
                },
            })
            .then((response) => {
                if (response.ok) {
                    return response.text();
                } else {
                    const error = new Error(response.statusText);
                    throw error;
                }
            })
    );
}

async function downloadQuestionnaireResults(questionnaireId) {
    const statusCheckEndpoint = API_HOME + "questionnaire/" + questionnaireId + "/results";
    return timeoutPromise(
        10000,
        polyOut
            .fetch(statusCheckEndpoint, {
                headers: {
                    "User-Agent": userAgent(),
                },
            })
            .then((response) => {
                if (response.ok) {
                    return response.text();
                } else {
                    const error = new Error(response.statusText);
                    throw error;
                }
            })
    );
}

async function downloadActiveQuestionnairesMetadata() {
    const statusCheckEndpoint = API_HOME + "questionnaires";
    return timeoutPromise(
        10000,
        polyOut
            .fetch(statusCheckEndpoint, {
                headers: {
                    "User-Agent": userAgent(),
                },
            })
            .then((response) => {
                if (response.ok) {
                    return response.text();
                } else {
                    const error = new Error(response.statusText);
                    throw error;
                }
            })
    );
}

//TODO implement timeout
function timeoutPromise(timeout, promise) {
    return promise;
}

//TODO implement agent with versionnumber
function userAgent() {
    return "PolyPoly";
}

const storage = new Map();

//TODO implement storage

const AsyncStorage = {
    async getItem(key) {
        return storage.get(key);
    },

    async setItem(key, value) {
        storage.set(key, value);
    },
};

const INDEX_KEY = "questionaires-index";

function questionnaireDataStorageId(questionnaireId) {
    return "questionnaire-" + questionnaireId + "-data";
}

function questionnaireResultsStorageId(questionnaireId) {
    return "questionnaire-" + questionnaireId + "-results-update";
}

async function loadQuestionnaireIndex() {
    const questionairesIndexJson = await AsyncStorage.getItem(INDEX_KEY);
    if (questionairesIndexJson == null) {
        return [];
    }
    return JSON.parse(questionairesIndexJson);
}

async function hasQuestionnaires() {
    const questionairesIndex = await loadQuestionnaireIndex();
    return questionairesIndex && questionairesIndex.length > 0;
}

async function loadQuestionnaireDataJson(questionnaireIndex) {
    if (!(await hasQuestionnaires())) {
        return null;
    }

    const questionnaireDataJson = await AsyncStorage.getItem(
        questionnaireDataStorageId(questionnaireIndex)
    );
    if (!questionnaireDataJson) {
        return null;
    }

    return questionnaireDataJson;
}

async function appendQuestionnaireToIndex(questionnaireId) {
    const questionairesIndex = await loadQuestionnaireIndex();
    questionairesIndex.push(questionnaireId);
    await AsyncStorage.setItem(INDEX_KEY, JSON.stringify(questionairesIndex));
}

async function storeQuestionnaireData(
    questionnaireId,
    questionnaireDataJson
) {
    await AsyncStorage.setItem(questionnaireDataStorageId(questionnaireId), questionnaireDataJson);
}

async function loadStoredQuestionnaireResultsJson(questionnaireId) {
    return await AsyncStorage.getItem(questionnaireResultsStorageId(questionnaireId));
}

async function storeQuestionnaireResults(questionnaireId, resultsData) {
    await AsyncStorage.setItem(
        questionnaireResultsStorageId(questionnaireId),
        JSON.stringify(resultsData)
    );
    return resultsData;
}

function questionnaireAnswersStorageId(questionnaireId) {
    return "questionnaire-" + questionnaireId + "-answers";
}

async function storeAnswers(questionnaire) {
    const storageKey = questionnaireAnswersStorageId(questionnaire.id);
    const jsonContent = JSON.stringify(questionnaire.answerJSON());

    await AsyncStorage.setItem(storageKey, jsonContent);
}

async function loadAnswers(questionnaire) {
    const storageKey = questionnaireAnswersStorageId(questionnaire.id);
    const answers = await AsyncStorage.getItem(storageKey);
    if (answers != null) {
        const content = JSON.parse(answers);
        questionnaire.loadAnswers(content);
    }
}

const QuestionnaireListContext = React.createContext







({} );

const QuestionnaireListProvider = ({ children }) => {
    const { i18n } = useTranslation();

    // State to indicate when the list of questionnaire is initialized.
    const [questionaireInitializationStatus, setQuestionaireInitializationStatus] = React.useState(false);
    const [questionnaireList, setQuestionnaireList] = React.useState([]);

    const triggerUpdate = () => {
        setQuestionnaireList([...questionnaireList]);
    };

    /**
     * I save questionnaire on disk without notifying any UI updates
     */
    const saveQuestionnaireAnswers = (questionnaire) => {
        storeAnswers(questionnaire);
    };

    const markQuestionaireSubmitted = (questionnaire) => {
        questionnaire.updateSubmittedTime();
        saveQuestionnaireAnswers(questionnaire);
        triggerUpdate();
    };

    const buildQuestionnaireObject = (questionaireDataJson) => {
        const currentQuestionaireData = JSON.parse(questionaireDataJson, PpQReplacer);
        const currentQuestionaire = currentQuestionaireData.questionnaire;
        currentQuestionaire.postJSONLoad();
        currentQuestionaire.loadTranslations(i18n, currentQuestionaireData.languages);
        return currentQuestionaire;
    };

    const ensureLanguage = async (questionnaire) => {
        // If after loading a questionnaire the language is not set, use the current language.
        if (questionnaire.question_language === null) {
            const languageCode = await getStoredLanguage();
            questionnaire.question_language = languageCode;
        }
    };

    const downloadAndStoreQuestionnaire = async function (questionaireMetadata) {
        const responseContent = await downloadQuestionnaireData(
            questionaireMetadata.questionnaireId
        );
        const currentQuestionaire = buildQuestionnaireObject(responseContent);

        await storeQuestionnaireData(currentQuestionaire.id, responseContent);
        await appendQuestionnaireToIndex(currentQuestionaire.id);

        // Set the current language as the language of the questionnaire after download.
        await ensureLanguage(currentQuestionaire);
        return currentQuestionaire;
    };

    const getNewActiveQuestionnairesMetadata = async () => {
        const resultValue = await downloadActiveQuestionnairesMetadata();
        const allActiveQuestionnairesMetadata = JSON.parse(resultValue);
        if (
            allActiveQuestionnairesMetadata === null ||
            allActiveQuestionnairesMetadata.length === 0
        ) {
            return [];
        }

        const questionnairesIndex = questionnaireList.map((questionnaire) => questionnaire.id);
        const newMetadata = [];
        for (const questionaireMetadata of allActiveQuestionnairesMetadata) {
            if (!questionnairesIndex.includes(questionaireMetadata.questionnaireId)) {
                newMetadata.push(questionaireMetadata);
            }
        }
        return newMetadata;
    };

    const updateQuestionnaireResults = async (questionnaire) => {
        const responseContent = await downloadQuestionnaireResults(questionnaire.id);
        const responseValue = JSON.parse(responseContent);
        if (responseValue.result_status === "available" && responseValue.result_url) {
            const result = new PpQuestionnaireLinkResult();
            result.url = responseValue.result_url;

            questionnaire.result = result;
            await storeQuestionnaireResults(questionnaire.id, result.toJSON());
        }
    };

    const updateStoredQuestionnaires = async () => {
        const questionnairesMetadata = await getNewActiveQuestionnairesMetadata();

        const downloadedQuestionnaires = [];
        try {
            for (const questionaireMetadata of questionnairesMetadata) {
                const currentQuestionnaire = await downloadAndStoreQuestionnaire(
                    questionaireMetadata
                );
                downloadedQuestionnaires.push(currentQuestionnaire);
            }

            const noResultsQuestionnaires = questionnaireList.filter(
                (questionnaire) =>
                    questionnaire.hasResult() === false &&
                    (questionnaire.isSubmitted() || questionnaire.isExpired())
            );
            for (const questionaire of noResultsQuestionnaires) {
                await updateQuestionnaireResults(questionaire);
            }
        } catch (ex) {
            console.log(ex);
        } finally {
            setQuestionnaireList([...questionnaireList, ...downloadedQuestionnaires]);
        }
    };

    const loadResults = async (questionnaire) => {
        const questionnaireResultsJson = await loadStoredQuestionnaireResultsJson(questionnaire.id);
        if (questionnaireResultsJson !== null) {
            const questionnaireResults = JSON.parse(questionnaireResultsJson, PpQReplacer);
            questionnaireResults.postJSONLoad();
            questionnaire.result = questionnaireResults;
        }
    };

    /**
     * Main effect: load the questionnaire data from storage when app is started.
     */
    React__default.useEffect(() => {
        const loadInitialQuestionnaires = async function () {
            const loadedQuestionnaires = [];
            const questionnairesIndexList = await loadQuestionnaireIndex();
            for (const questionnaireId of questionnairesIndexList) {
                const currentQuestionaireDataJson = await loadQuestionnaireDataJson(
                    questionnaireId
                );
                const currentQuestionaire = buildQuestionnaireObject(currentQuestionaireDataJson);

                await loadAnswers(currentQuestionaire);
                await loadResults(currentQuestionaire);

                loadedQuestionnaires.push(currentQuestionaire);
            }
            setQuestionnaireList(loadedQuestionnaires);
        };
        loadInitialQuestionnaires().finally(() =>
            // Mark the questionnaire as initialized in a finally bloc,
            // to be set even if there is an error during initialization.
            setQuestionaireInitializationStatus(true)
        );
    }, []);

    return (
        React__default.createElement(QuestionnaireListContext.Provider, {
            value: {
                triggerUpdate,
                saveQuestionnaireAnswers,
                markQuestionaireSubmitted,
                questionaireInitializationStatus,
                questionnaireList,
                setQuestionnaireList,
                updateStoredQuestionnaires,
            },}
        
            , children
        )
    );
};

const QuestionnaireContext = React.createContext













({} );

class QuestionnaireHolder {
    
    constructor(questionnaire) {
        this._questionnaire = questionnaire;
    }

    copy() {
        return new QuestionnaireHolder(this.questionnaire);
    }
    copyWith(newQuestionnaire) {
        return new QuestionnaireHolder(newQuestionnaire);
    }

    get questionnaire() {
        return this._questionnaire;
    }
}

const INITIAL_VALUE = new QuestionnaireHolder(new PpQuestionnaire());

const QuestionnaireProvider = ({ children }) => {
    const [questionnaireHolder, setQuestionnaireHolder] = React.useState(INITIAL_VALUE);
    const [currentQuestion, setCurrentQuestion] = React.useState();

    const switchToNextQuestion = () => {
        const nextQuestion = getQuestionnaire().activeQuestionAfter(currentQuestion);
        if (nextQuestion) {
            setCurrentQuestion(nextQuestion);
        }
    };

    const switchToPreviousQuestion = () => {
        const previousQuestion = getQuestionnaire().activeQuestionBefore(currentQuestion);
        if (previousQuestion) {
            setCurrentQuestion(previousQuestion);
        }
    };

    const switchToFirstQuestion = () => {
        const firstQuestion = getQuestionnaire().firstActiveQuestion();
        if (firstQuestion) {
            setCurrentQuestion(firstQuestion);
        }
    };

    const setQuestionnaireAndSwitchToFirstUnansweredQuestion = (questionnaire) => {
        setQuestionnaire(questionnaire);
        const unansweredQuestion = questionnaire.firstUnansweredQuestion();
        if (unansweredQuestion) {
            setCurrentQuestion(unansweredQuestion);
        }
    };

    /**
     * @returns {PpQuestionnaire} - the underlying Questionnaire model
     */
    const getQuestionnaire = () => questionnaireHolder.questionnaire;

    const setQuestionnaire = (newQuestionnaire) => {
        setQuestionnaireHolder(questionnaireHolder.copyWith(newQuestionnaire));
    };

    /**
     * Let React know that the questionnaire changed,
     * this will trigger re-rendering of all components
     * that use this content
     */
    const notifyUpdated = () => {
        setQuestionnaireHolder(questionnaireHolder.copy());
    };

    /**
     * Return true if a given question is the first question
     * @param question
     * @returns {boolean}
     */
    const isFirstQuestion = (question) => {
        return getQuestionnaire().isFirstQuestion(question);
    };

    /**
     * Return true if a given question is the last question
     * @param question
     * @returns {boolean}
     */
    const isLastQuestion = (question) => {
        return getQuestionnaire().isLastQuestion(question);
    };

    /**
     * Return true if we are currently at the first question
     * @returns {boolean}
     */
    const isAtFirstQuestion = () => {
        return !currentQuestion || isFirstQuestion(currentQuestion);
    };

    /**
     * Return true if we are currently at the first question
     * @returns {boolean}
     */
    const isAtLastQuestion = () => {
        return currentQuestion && isLastQuestion(currentQuestion);
    };

    return (
        React__default.createElement(QuestionnaireContext.Provider, {
            value: {
                questionnaireHolder,
                currentQuestion,
                getQuestionnaire,
                setQuestionnaire,
                isFirstQuestion,
                isAtFirstQuestion,
                isLastQuestion,
                isAtLastQuestion,
                notifyUpdated,
                switchToNextQuestion,
                switchToPreviousQuestion,
                switchToFirstQuestion,
                setQuestionnaireAndSwitchToFirstUnansweredQuestion,
            },}
        
            , children
        )
    );
};

function LoadingScreen() {
    return React__default.createElement('div', null, "Loading");
}

function StartSurveyButton({
    questionnaire,
    route,
}


) {
    const { setQuestionnaireAndSwitchToFirstUnansweredQuestion } = React.useContext(QuestionnaireContext);
    return (
        React__default.createElement(reactRouterDom.Link, {
            className: "button inverted" ,
            onClick: () => setQuestionnaireAndSwitchToFirstUnansweredQuestion(questionnaire),
            to: route,}
        , "Start"

        )
    );
}

//TODO implement questionnaire state
function MainSurveyCard({ questionnaire }) {
    const { t, i18n } = useTranslation();

    const title = t(questionnaire.title);
    return (
        React.createElement('section', { className: "card",}
            , React.createElement('header', null
                , React.createElement('h1', { className: "card-title",}, title)
            )
            , React.createElement('main', null
                , React.createElement('p', { className: "card-content",}, "Der Einsendeschluss ist am"

                    , React.createElement('br', null )
                    , React.createElement('strong', null, questionnaire.submissionDeadlineString(i18n.language))
                )
            )
            , React.createElement('footer', null
                , React.createElement(StartSurveyButton, { questionnaire: questionnaire, route: "/intro",} )
            )
        )
    );
}

var tabs = createCommonjsModule(function (module, exports) {
var __createBinding = (commonjsGlobal && commonjsGlobal.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (commonjsGlobal && commonjsGlobal.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (commonjsGlobal && commonjsGlobal.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tab = exports.Tabs = void 0;
const React = __importStar(React__default);
exports.Tabs = ({ children }) => (React.createElement("nav", { className: "tabs" },
    React.createElement("ul", null, children)));
exports.Tab = (props) => {
    const { children, active = false } = props;
    return React.createElement("li", { className: active ? "tabs-active" : undefined }, children);
};
});

function ActiveSurveys() {
    const { questionnaireList } = React.useContext(QuestionnaireListContext);

    const activeQuestionnaire = questionnaireList; //.filter(questionnaire =>
    //questionnaire.isActive(),
    //);

    // TODO: Adjust the link targets
    return (
        React.createElement(React.Fragment, null
            , React.createElement(tabs.Tabs, null
                , React.createElement(tabs.Tab, { active: true,}
                    , React.createElement('a', { href: "/",}, "Featured")
                )
                , React.createElement(tabs.Tab, null
                    , React.createElement('a', { href: "/",}, "Übermittelt")
                )
                , React.createElement(tabs.Tab, null
                    , React.createElement('a', { href: "/",}, "Abgelaufen")
                )
            )
            , activeQuestionnaire.map((questionnaire) => (
                React.createElement(MainSurveyCard, { key: questionnaire.id, questionnaire: questionnaire,} )
            ))
        )
    );
}

var header = createCommonjsModule(function (module, exports) {
var __importDefault = (commonjsGlobal && commonjsGlobal.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BigHeader = exports.SmallHeader = void 0;
const react_1 = __importDefault(React__default);
exports.SmallHeader = ({ children }) => (react_1.default.createElement("header", { className: "small-header" }, children));
exports.BigHeader = ({ children }) => (react_1.default.createElement("header", { className: "big-header" }, children));
});

var footer = createCommonjsModule(function (module, exports) {
var __createBinding = (commonjsGlobal && commonjsGlobal.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (commonjsGlobal && commonjsGlobal.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (commonjsGlobal && commonjsGlobal.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CenteredFooter = void 0;
const React = __importStar(React__default);
exports.CenteredFooter = ({ children }) => (React.createElement("footer", { className: "centered-footer" }, children));
});

var layout = createCommonjsModule(function (module, exports) {
var __createBinding = (commonjsGlobal && commonjsGlobal.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (commonjsGlobal && commonjsGlobal.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (commonjsGlobal && commonjsGlobal.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Layout = void 0;
const React = __importStar(React__default);
exports.Layout = (props) => {
    const { header, footer, children } = props;
    return (React.createElement("div", { className: "layout" },
        header,
        children,
        footer));
};
});

function HomeHeader() {
    return (
        React__default.createElement(header.SmallHeader, null
            , React__default.createElement('h1', { className: "page-title",}
                , React__default.createElement(reactRouterDom.Link, { to: "/home",}, "polyPod")
            )
        )
    );
}

function HomeFooter() {
    return (
        React__default.createElement(footer.CenteredFooter, null
            , React__default.createElement('button', null, "Prüfe auf neue Umfragen"   )
        )
    );
}

function HomeScreen() {
    return (
        React__default.createElement(layout.Layout, { header: React__default.createElement(HomeHeader, null ), footer: React__default.createElement(HomeFooter, null ),}
            , React__default.createElement('main', null
                , React__default.createElement(ActiveSurveys, null )
            )
        )
    );
}

function QuestionCard({
    index,
    question,
    instruction = "",
    AnswerComponent = () => React__default.createElement('div', null ),
    AcceptComponent = () => React__default.createElement('div', null ),
}) {
    return (
        React__default.createElement('main', { className: "question-card",}
            , React__default.createElement('strong', { className: "question-card-index",}, index + 1)
            , React__default.createElement('h1', { className: "question-card-question",}, question)
            , instruction.length > 0 && React__default.createElement('p', { className: "question-card-instruction",}, instruction)
            , React__default.createElement(AnswerComponent, null )
            , React__default.createElement(AcceptComponent, null )
        )
    );
}

function PolyCheckbox(props = {}) {
    const {
        item = undefined,
        index = 1,
        indexExtractor = (_index) => _index,

        label = "Checkbox",
        onChecked = (_checkbox) => {},
        checked = false,
        disabled = false,
        grouped = false,
    } = props;

    const [isChecked, setIsChecked] = React.useState(checked);

    const amChecked = React__default.useCallback(() => (grouped ? checked : isChecked), [
        checked,
        grouped,
        isChecked,
    ]);

    const onPress = React__default.useCallback(() => {
        if (!disabled) {
            if (!grouped) {
                setIsChecked(!amChecked());
            }
            onChecked({
                checked: !amChecked(),
                index: index,
                label: label,
                props: props,
                item: item,
            });
        }
    }, [amChecked, disabled, grouped, index, item, label, onChecked, props]);

    return (
        React__default.createElement('div', { className: "choice",}
            , React__default.createElement('input', {
                id: `choice-${index}`,
                className: "choice-input",
                type: "checkbox",
                checked: amChecked(),
                onChange: onPress,}
            )
            , React__default.createElement('label', { className: "choice-label", htmlFor: `choice-${index}`,}
                , React__default.createElement('div', { className: "choice-index",}, indexExtractor(index))
                , React__default.createElement('div', { className: "choice-text",}, label)
            )
        )
    );
}

function compareMaps(map1, map2) {
    let testVal;
    if (map1.size !== map2.size) {
        return false;
    }
    for (const [key, val] of map1) {
        testVal = map2.get(key);
        // in cases of an undefined value, make sure the key
        // actually exists on the object so there are no false positives
        if (testVal !== val || (testVal === undefined && !map2.has(key))) {
            return false;
        }
    }
    return true;
}

const indices = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

function PolyCheckboxGroup(props = {}) {
    const {
        options = [],
        label = (_item, _index) => _item,
        value = (_item, _index) => _item,
        checked = (_item, _index) => false,
        disabled = (_item, _index) => false,
        onChecked = () => {},
    } = props;

    const newChecked = new Map(options.map((each, index) => [index, checked(each, index)]));

    const newDisabled = new Map(options.map((each, index) => [index, disabled(each, index)]));

    const [selectedCheckboxes, setSelectedCheckboxes] = React.useState(newChecked);
    const [disabledCheckboxes, setDisabledCheckboxes] = React.useState(newDisabled);

    /*
      Unfortunately React does not understand when checked or disabled map was changed,
      so we have to do it manually here
     */
    if (!compareMaps(newChecked, selectedCheckboxes)) {
        setSelectedCheckboxes(newChecked);
    }

    if (!compareMaps(newDisabled, disabledCheckboxes)) {
        setDisabledCheckboxes(newChecked);
    }

    const onSelect = React__default.useCallback(
        (checkbox) => {
            const newSelected = new Map(selectedCheckboxes);
            newSelected.set(checkbox.index, checkbox.checked);
            setSelectedCheckboxes(newSelected);
            onChecked(checkbox);
        },
        [onChecked, selectedCheckboxes]
    );

    return (
        React__default.createElement('div', { className: "checkbox-group",}
            , options.map((item, index) => (
                React__default.createElement(PolyCheckbox, {
                    index: index,
                    key: index.toString(),
                    indexExtractor: 
                        options.length > indices.length
                            ? () => null
                            : (_index) => indices.charAt(_index)
                    ,
                    label: label(item, index),
                    value: value(item, index),
                    item: item,
                    checked: !!selectedCheckboxes.get(index),
                    disabled: !!disabledCheckboxes.get(index),
                    grouped: true,
                    onChecked: onSelect,}
                )
            ))
        )
    );
}

function PolyButton({
    title = "generic.button.okay",
    inverted = false,
    childrenBefore = [],
    childrenAfter = [],
    onPress = () => {},
}) {
    const { t } = useTranslation();

    return (
        React__default.createElement('button', { onClick: onPress, className: inverted ? "inverted" : null,}
            , childrenBefore
            , t(title)
            , childrenAfter
        )
    );
}

function NextButton() {
    const { isAtLastQuestion, switchToNextQuestion } = React.useContext(QuestionnaireContext);
    const { triggerUpdate } = React.useContext(QuestionnaireListContext);

    const history = reactRouterDom.useHistory();

    return (
        React__default.createElement(PolyButton, {
            title: "generic.button.okay",
            inverted: true,
            onPress: () => {
                triggerUpdate();
                if (isAtLastQuestion()) {
                    history.push("/survey-completed");
                } else {
                    switchToNextQuestion();
                }
            },}
        )
    );
}

function MultipleChoiceQuestion({ index, question }) {
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const { saveQuestionnaireAnswers } = React.useContext(QuestionnaireListContext);

    return (
        React__default.createElement(QuestionCard, {
            index: index,
            question: question.description(),
            instruction: question.explanation(),
            AnswerComponent: () => (
                React__default.createElement(PolyCheckboxGroup, {
                    detoxindex: index,
                    options: question.choices(),
                    label: (choice) => choice.value(),
                    value: (choice) => choice.id,
                    checked: (choice) => choice.isSelected(),
                    disabled: (choice) => !choice.enabled,
                    onChecked: (checkbox) => {
                        checkbox.item.selected(checkbox.checked);
                        saveQuestionnaireAnswers(getQuestionnaire());
                        // notifyUpdated() is required to re-render the UI and checkbox states

                        // triggerUpdate();
                    },}
                )
            ),
            AcceptComponent: () => React__default.createElement(NextButton, null ),}
        )
    );
}

function TextInput({ onChangeText, value, placeholder, maxLength, multiline, numberOfLines }) {
    if (multiline)
        return (
            React__default.createElement('textarea', {
                onChange: (event) => onChangeText(event.target.value),
                value: value,
                placeholder: placeholder,
                maxLength: maxLength,
                rows: numberOfLines,}
            )
        );

    return (
        React__default.createElement('input', {
            onChange: (event) => onChangeText(event.target.value),
            type: "text",
            value: value,
            placeholder: placeholder,
            maxLength: maxLength,}
        )
    );
}

function PolyTextInput({
    initialText = "",
    onChangeText = (_text) => {},
    maxLength = undefined,
    multiline = undefined,
    numberOfLines = undefined,
    oneWord = false,
}) {
    const { t } = useTranslation();
    const [value, setValue] = React.useState(initialText || "");
    const [errMessage, setErrMessage] = React.useState("");

    const inputValid = (text) => {
        return !oneWord || text.indexOf(" ") < 0;
    };

    let validText;

    return (
        React__default.createElement(React__default.Fragment, null
            , React__default.createElement(TextInput, {
                onChangeText: (text) => {
                    if (inputValid(text)) {
                        setErrMessage("");
                        setValue(text);
                        onChangeText(text);
                    } else {
                        validText = text.replace(/\s/g, "");
                        setErrMessage(t("validation.only-one-word"));
                        setValue(validText);
                        onChangeText(validText);
                    }
                },
                value: value,
                placeholder: t("general.text-input-shadow-text"),
                maxLength: maxLength,
                multiline: multiline,
                numberOfLines: numberOfLines,}
            )
            , errMessage
        )
    );
}

function TextQuestion({ index, question }) {
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const { saveQuestionnaireAnswers } = React.useContext(QuestionnaireListContext);

    return (
        React__default.createElement(QuestionCard, {
            index: index,
            question: question.description(),
            instruction: question.explanation(),
            AnswerComponent: () => (
                React__default.createElement(PolyTextInput, {
                    initialText: question.answer(),
                    maxLength: question.maxLength,
                    multiline: question.multiline,
                    numberOfLines: question.numberOfLines,
                    oneWord: question.oneWordValidation,
                    onChangeText: (text) => {
                        question.setAnswer(text);
                        saveQuestionnaireAnswers(getQuestionnaire());
                        // we should not notifyUpdated() here,
                        // otherwise the component will be re-rendered and keyboard will hide
                    },}
                )
            ),
            AcceptComponent: () => React__default.createElement(NextButton, null ),}
        )
    );
}

function PolyIconButton({ icon = React__default.createElement('div', null ), onPress, disabled = false }) {
    return (
        React__default.createElement('button', { disabled: disabled, onClick: onPress,}
            , icon
        )
    );
}

function PolyRangeButton({
    label = "1",
    index = 1,
    item,
    onChecked = (range) => {},
    disabled = false,
    checked = false,
}) {
    if (checked) label = label + "*";
    return (
        React__default.createElement(PolyIconButton, {
            icon: React__default.createElement('strong', null, label),
            disabled: disabled,
            onPress: () => {
                onChecked({
                    index: index,
                    item,
                    checked: !checked,
                });
            },}
        )
    );
}

function PolyRange(props = {}) {
    const {
        options = [],
        limits = [],
        label = (_item, _index) => _item,
        checked,
        disabled = (_item, _index) => false,
        onChecked = () => {},
    } = props;

    const newChecked = checked
        ? new Map(options.map((each, index) => [index, checked(each, index)]))
        : new Map();

    const newDisabled = new Map(options.map((each, index) => [index, disabled(each, index)]));

    const [selectedCheckboxes, setSelectedCheckboxes] = React.useState(newChecked);
    const [disabledCheckboxes, setDisabledCheckboxes] = React.useState(newDisabled);

    /*
      Unfortunately React does not understand when checked or disabled map was changed,
      so we have to do it manually here
     */
    if (checked && !compareMaps(newChecked, selectedCheckboxes)) {
        setSelectedCheckboxes(newChecked);
    }

    if (!compareMaps(newDisabled, disabledCheckboxes)) {
        setDisabledCheckboxes(newChecked);
    }

    const onSelect = (checkbox) => {
        const newSelected = new Map(selectedCheckboxes);
        newSelected.set(checkbox.index, checkbox.checked);
        setSelectedCheckboxes(newSelected);
        onChecked(checkbox);
    };

    return (
        React__default.createElement('div', null
            , options.map((item, index) => (
                React__default.createElement(PolyRangeButton, {
                    label: label(item, index),
                    index: index,
                    key: index.toString(),
                    item: item,
                    checked: !!selectedCheckboxes.get(index),
                    disabled: !!disabledCheckboxes.get(index),
                    onChecked: onSelect,}
                )
            ))
            , limits[0]
            , limits[1]
        )
    );
}

function RangeQuestion({ index, question }) {
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const { saveQuestionnaireAnswers } = React.useContext(QuestionnaireListContext);

    return (
        React__default.createElement(QuestionCard, {
            index: index,
            question: question.description(),
            instruction: question.explanation(),
            AnswerComponent: () => (
                React__default.createElement(PolyRange, {
                    options: question.values(),
                    checked: (option) => option === question.value(),
                    limits: question.labels,
                    onChecked: (checkbox) => {
                        if (checkbox.checked) {
                            question.setValue(checkbox.item);
                        } else {
                            question.setValue(null);
                        }
                        saveQuestionnaireAnswers(getQuestionnaire());
                    },}
                )
            ),
            AcceptComponent: () => React__default.createElement(NextButton, null ),}
        )
    );
}

function QuestionnaireProgress({ questionnaire }) {
    const { t } = useTranslation();

    const numberOfQuestions = questionnaire.activeQuestions().length;
    const numberOfAnsweredQuestions = questionnaire.answeredQuestions().length;

    return (
        React__default.createElement('div', { className: "questionnaire-progress",}
            , React__default.createElement('div', null
                , React__default.createElement('strong', null, numberOfAnsweredQuestions)
                , ` ${t("generic.footer.progress.of")} `
                , React__default.createElement('strong', null, numberOfQuestions)
                , ` ${t("generic.footer.progress.answered")} `
            )
            , React__default.createElement('progress', { max: numberOfQuestions, value: numberOfAnsweredQuestions,} )
        )
    );
}

function FooterNavigation() {
    const {
        isAtFirstQuestion,
        isAtLastQuestion,
        getQuestionnaire,
        switchToNextQuestion,
        switchToPreviousQuestion,
    } = React.useContext(QuestionnaireContext);
    const history = reactRouterDom.useHistory();

    const goToNext = () => {
        if (isAtLastQuestion()) {
            history.push("/survey-completed");
        } else {
            switchToNextQuestion();
        }
    };

    return (
        React__default.createElement('div', { className: "questionnaire-footer",}
            , React__default.createElement(QuestionnaireProgress, { questionnaire: getQuestionnaire(),} )
            , React__default.createElement('button', {
                className: "alt",
                disabled: isAtFirstQuestion(),
                onClick: switchToPreviousQuestion,}
            
                , React__default.createElement('img', { src: "./icons/chevron.svg", alt: "previous", className: "chevron-up",} )
            )
            , React__default.createElement('button', { onClick: goToNext, className: "alt",}
                , React__default.createElement('img', { src: "./icons/chevron.svg", alt: "next", className: "chevron-down",} )
            )
        )
    );
}

function QuestionScreen() {
    const { currentQuestion } = React.useContext(QuestionnaireContext);

    if (!currentQuestion) {
        return React__default.createElement('div', null );
    }

    const components = {
        TextQuestion: TextQuestion,
        MultipleChoiceQuestion: MultipleChoiceQuestion,
        RangeQuestion: RangeQuestion,
    };

    const Card = components[currentQuestion.screen() ];

    return (
        React__default.createElement(layout.Layout, { header: React__default.createElement('div', null ), footer: React__default.createElement(FooterNavigation, null ),}
            , React__default.createElement(Card, { index: currentQuestion.index, question: currentQuestion,} )
        )
    );
}

function IntroHeader({ questionnaire }) {
    const { t, i18n } = useTranslation();

    return (
        React__default.createElement(header.BigHeader, null
            , React__default.createElement('p', null
                , `${t("intro.survey_by")} `
                , React__default.createElement('strong', null, t(questionnaire.author.name))
            )
            , React__default.createElement('h1', null, t(questionnaire.title).toUpperCase())
            , React__default.createElement('p', null
                , `${t("intro.published")}: `
                , React__default.createElement('strong', null, questionnaire.publishedDateString(i18n.language))
            )
            , React__default.createElement('p', null
                , `${t("intro.expires")}: `
                , React__default.createElement('strong', null, questionnaire.submissionDeadlineString(i18n.language))
            )
        )
    );
}

function ActionButtons({ questionnaire }) {
    return (
        React__default.createElement(footer.CenteredFooter, null
            , React__default.createElement(StartSurveyButton, { questionnaire: questionnaire, route: "/survey",} )
        )
    );

    /* TODO:
     Depending on isActive, hasAnsweredQuestions, hasResults show:

      <ContinueSurveyButton
        title={t('intro.button.continue')}
        questionnaire={questionnaire}
      />
      <ResultsSurveyButton
        title={t('intro.button.results')}
        questionnaire={questionnaire}
      />
      <ReviewSurveyButton
        title={t('intro.button.view')}
        questionnaire={questionnaire}
      />
   */
}

function Description({ questionnaire }) {
    const { t } = useTranslation();

    return React__default.createElement('p', null, t(questionnaire.description));
}

function Author({ questionnaire }) {
    const { t } = useTranslation();

    return (
        // TODO onPress={() => navigation.navigate(AuthorDetailsScreenRoute)}>
        React__default.createElement(reactRouterDom.Link, { to: "/intro/authordetails", className: "call-out-section",}
            , React__default.createElement('strong', null, t(questionnaire.author.name))
            , React__default.createElement('p', null, t("intro.author"))
        )
    );
}

function SubmissionDate({ questionnaire }) {
    const { t, i18n } = useTranslation();

    return questionnaire.isSubmitted() ? (
        React__default.createElement('div', null
            , `${t("intro.submitted")}: `
            , questionnaire.submittedTimeString(i18n.language)
        )
    ) : null;
}

const IntroScreen = function () {
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const questionnaire = getQuestionnaire();

    return (
        React__default.createElement(layout.Layout, {
            header: React__default.createElement(IntroHeader, { questionnaire: questionnaire,} ),
            footer: React__default.createElement(ActionButtons, { questionnaire: questionnaire,} ),}
        
            , React__default.createElement('main', null
                , React__default.createElement(Description, { questionnaire: questionnaire,} )
                , React__default.createElement(Author, { questionnaire: questionnaire,} )
                , React__default.createElement(SubmissionDate, { questionnaire: questionnaire,} )
            )
        )
    );
};

const AuthorDetailsScreen = function () {
    const { t } = useTranslation();
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const questionnaire = getQuestionnaire();

    const history = reactRouterDom.useHistory();
    /* TODO "Back" übersetzen */
    return (
        React__default.createElement('div', null
            , t(questionnaire.author.name)
            , t(questionnaire.author.description)
            , React__default.createElement(PolyButton, {
                title: t("Back"),
                onPress: () => {
                    history.goBack();
                },}
            )
        )
    );
};

function IntroNavigator() {
    return (
        React__default.createElement(reactRouterDom.Switch, null
            , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/intro",}
                , React__default.createElement(IntroScreen, null )
            )
            , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/intro/authordetails",}
                , React__default.createElement(AuthorDetailsScreen, null )
            )
        )
    );
}

function ReviewSurveyButton({ title = "generic.button.review", questionnaire }) {
    const history = reactRouterDom.useHistory();
    const { setQuestionnaire } = React.useContext(QuestionnaireContext);

    return (
        React__default.createElement(PolyButton, {
            title: title,
            onPress: () => {
                if (questionnaire) {
                    setQuestionnaire(questionnaire);
                }
                history.push("/answers");
            },}
        )
    );
}

function FinalizeSurveyButton({ title }) {
    const history = reactRouterDom.useHistory();

    return (
        React__default.createElement(PolyButton, {
            title: title,
            onPress: () => {
                history.push("/survey-legal");
            },}
        )
    );
}

const SurveyCompletedScreen = function () {
    const { t } = useTranslation();
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);

    /* <Image
            style={[styles.image, {maxHeight: height}]}
            resizeMode={'contain'}
            source={backgroundImage}
          />*/
    return (
        React__default.createElement('div', null
            , t("survey.screen_completed.thank_you")
            , React__default.createElement(FinalizeSurveyButton, { title: t("survey.button.finalize"),} )
            , React__default.createElement(ReviewSurveyButton, {
                title: t("survey.button.review"),
                questionnaire: getQuestionnaire(),}
            )
        )
    );
};

function Loader({ loading }) {
    // TODO this should be a spinner
    return React__default.createElement('div', { className: loading ? "" : "invisible",}, "Loading ..." );
}

// TODO real submission
async function submitAnswers(questionnaire) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const random = Math.random();
            if (random < 0.2) resolve();
            else reject();
        }, 1000);
    });
}

function SubmitSurveyButton({ title, onStart = () => {}, onFinished = () => {} }) {
    const { markQuestionaireSubmitted } = React.useContext(QuestionnaireListContext);
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const history = reactRouterDom.useHistory();

    return (
        React__default.createElement(PolyButton, {
            title: title,
            onPress: () => {
                onStart();
                submitAnswers(getQuestionnaire())
                    .then(() => {
                        markQuestionaireSubmitted(getQuestionnaire());
                        onFinished();
                        history.push("/survey-submitted");
                    })
                    .catch((ex) => {
                        try {
                            console.error(ex);
                        } catch (_) {
                            /* do nothing */
                        }
                        // Make sure this is called, as otherwise the Loading screen will not dissapear.
                        onFinished();
                        history.push("/survey-error");
                    });
            },}
        )
    );
}

function SurveyLegalScreen() {
    const [showLoader, setShowLoader] = React.useState(false);
    const { t } = useTranslation();
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);
    const history = reactRouterDom.useHistory();

    // TODO figure out how Trans works
    return (
        React__default.createElement('div', null
            , React__default.createElement(Loader, { loading: showLoader,} )
            , React__default.createElement('div', null, t("survey.screen_legal.title"))
            , React__default.createElement('div', null
                , React__default.createElement(Trans, { i18nKey: getQuestionnaire().legal.content,}, "leading"

                    , React__default.createElement('a', { href: t(getQuestionnaire().legal.link),}, getQuestionnaire().legal.link)
                )
            )
            , React__default.createElement('div', null
                , React__default.createElement(PolyButton, {
                    title: t("survey.button.disagree"),
                    onPress: () => {
                        history.goBack();
                    },}
                )
                , React__default.createElement(SubmitSurveyButton, {
                    title: t("survey.button.agree"),
                    onStart: () => setShowLoader(true),
                    onFinished: () => setShowLoader(false),}
                )
            )
        )
    );
}

function SubmittedScreen() {
    const { t } = useTranslation();
    const history = reactRouterDom.useHistory();

    return (
        React__default.createElement('div', null
            , t("survey.screen_submitted.answers_submited")
            , t("survey.screen_submitted.thank_you")
            , React__default.createElement(PolyButton, { title: t("survey.button.home"), onPress: () => history.push("/home"),} )
        )
    );
}

function AnswersSubmissionErrorScreen() {
    const [showLoader, setShowLoader] = React.useState(false);
    const { t } = useTranslation();
    const history = reactRouterDom.useHistory();

    return (
        React__default.createElement('div', null
            , React__default.createElement(Loader, { loading: showLoader,} )
            , t("survey.error.title")
            , t("survey.error.message")
            , React__default.createElement(SubmitSurveyButton, {
                title: t("survey.button.try_again"),
                onStart: () => setShowLoader(true),
                onFinished: () => setShowLoader(false),}
            )
            , React__default.createElement(PolyButton, {
                title: t("survey.button.home"),
                onPress: () => {
                    history.push("/home");
                },}
            )
        )
    );
}

function AnswerPreviewCard({
    question = "What is your lucky number?",
    AnswerComponent = () => React__default.createElement('div', null ),
}) {
    return (
        React__default.createElement('div', null
            , question
            , React__default.createElement(AnswerComponent, null )
        )
    );
}

function AnswerChoicePreview({ answer = "Any number" }) {
    return React__default.createElement('div', null, answer);
}

function AnswerChoiceGroupPreview(props = {}) {
    const { choices = [], labelExtractor = (item) => item } = props;

    return (
        React__default.createElement('div', null
            , React__default.createElement('ol', null
                , choices.map((item) => (
                    React__default.createElement('li', null
                        , React__default.createElement(AnswerChoicePreview, { answer: labelExtractor(item),} )
                    )
                ))
            )
        )
    );
}

function TextQuestionAnswerPreview({ question = new PpTextQuestion() }) {
    return (
        React__default.createElement(AnswerPreviewCard, {
            question: question.description(),
            AnswerComponent: () => (
                React__default.createElement(AnswerChoiceGroupPreview, {
                    choices: question.isAnswered() ? [question.value()] : [],}
                )
            ),}
        )
    );
}

function SingleChoiceQuestionAnswerPreview({
    question = new PpSingleChoiceQuestion(),
}) {
    return (
        React__default.createElement(AnswerPreviewCard, {
            question: question.description(),
            AnswerComponent: () => (
                React__default.createElement(AnswerChoiceGroupPreview, {
                    choices: question.isAnswered() ? [question.value()] : [],}
                )
            ),}
        )
    );
}

function MultipleChoiceQuestionAnswerPreview({
    question = new PpMultipleChoiceQuestion(),
}) {
    return (
        React__default.createElement(AnswerPreviewCard, {
            question: question.description(),
            AnswerComponent: () => React__default.createElement(AnswerChoiceGroupPreview, { choices: question.value(),} ),}
        )
    );
}

function RangeQuestionAnswerPreview({ question = new PpTextQuestion() }) {
    return (
        React__default.createElement(AnswerPreviewCard, {
            question: question.description(),
            AnswerComponent: () =>
                question.isAnswered() && (
                    // @ts-ignore
                    React__default.createElement(PolyRangeButton, { label: question.value(), checked: true, disabled: true,} )
                )
            ,}
        )
    );
}

function QuestionnaireAnswersList({ ListFooterComponent }) {
    const { getQuestionnaire } = React.useContext(QuestionnaireContext);

    return (
        React__default.createElement('div', null
            , React__default.createElement('ol', null
                , getQuestionnaire()
                    .questions()
                    .map((item) => {
                        let preview = React__default.createElement('div', null );
                        switch (item.constructor) {
                            case PpTextQuestion:
                                // TODO possible bug:
                                //   key 'test (de)' returned an object instead of string.
                                preview = React__default.createElement(TextQuestionAnswerPreview, { question: item,} );
                                break;
                            case PpSingleChoiceQuestion:
                                preview = React__default.createElement(SingleChoiceQuestionAnswerPreview, { question: item,} );
                                break;
                            case PpMultipleChoiceQuestion:
                                preview = React__default.createElement(MultipleChoiceQuestionAnswerPreview, { question: item,} );
                                break;
                            case PpRangeQuestion:
                                preview = React__default.createElement(RangeQuestionAnswerPreview, { question: item,} );
                                break;
                        }
                        return React__default.createElement('li', null, preview);
                    })
            )
            , React__default.createElement(ListFooterComponent, null )
        )
    );
}

function AnswersScreen() {
    const { t } = useTranslation();
    const history = reactRouterDom.useHistory();
    const { getQuestionnaire, switchToFirstQuestion } = React.useContext(QuestionnaireContext);

    return (
        React__default.createElement('div', null
            , getQuestionnaire().isActive()
                ? t("survey.screen_answers.description_before_submit")
                : getQuestionnaire().isSubmitted()
                ? t("survey.screen_answers.description_after_submit")
                : t("survey.screen_answers.description_not_submitted")
            , React__default.createElement(QuestionnaireAnswersList, {
                ListFooterComponent: () =>
                    getQuestionnaire().isActive() ? (
                        React__default.createElement('div', null
                            , React__default.createElement(FinalizeSurveyButton, { title: t("survey.button.finalize"),} )
                            , React__default.createElement(PolyButton, {
                                title: t("survey.button.edit"),
                                onPress: () => {
                                    switchToFirstQuestion();
                                    history.push("/survey");
                                },}
                            )
                        )
                    ) : (
                        React__default.createElement('div', null
                            , React__default.createElement(PolyButton, {
                                title: t("survey.button.home"),
                                onPress: () => {
                                    history.push("/home");
                                },}
                            )
                        )
                    )
                ,}
            )
        )
    );
}

function OnboardingScreenOne() {
    const { t } = useTranslation();
    const history = reactRouterDom.useHistory();
    return (
        React__default.createElement('div', null
            , t("onboarding.screen_01.title")

            , t("onboarding.screen_01.main_message")
            , React__default.createElement(PolyButton, {
                title: "onboarding.screen_01.button.continue",
                onPress: () => {
                    history.push("/onboarding2");
                },}
            )
        )
    );
}

function OnboardingScreenTwo() {
    const { t } = useTranslation();
    const history = reactRouterDom.useHistory();
    return (
        React__default.createElement('div', null
            , t("onboarding.screen_02.main_message")
            , React__default.createElement(PolyButton, {
                title: "onboarding.screen_02.button.continue",
                onPress: () => {
                    history.push("/onboarding3");
                },}
            )
        )
    );
}

// TODO Settings useEffect warum auch immer

function OnboardingScreenThree() {
    const { t } = useTranslation();
    const history = reactRouterDom.useHistory();
    return (
        React__default.createElement('div', null
            , t("onboarding.screen_03.main_message_02")
            , React__default.createElement(PolyButton, {
                title: "onboarding.screen_03.button.continue",
                onPress: () => {
                    history.push("/onboarding4");
                },}
            )
        )
    );
}

// TODO Settings useEffect warum auch immer

function OnboardingScreenFour() {
    const history = reactRouterDom.useHistory();

    const goToNextScreen = () => {
        AsyncStorage.setItem("onboardingshown", "true").then(() => {
            history.push("/home");
        });
    };

    return (
        React__default.createElement('div', null
            , React__default.createElement(Trans, { i18nKey: "onboarding.screen_04.message",}, "leading "
                 , React__default.createElement('strong', null, "polypoly"), "with "
                 , React__default.createElement('strong', null, "polyPod"), "trailing"

            )
            , React__default.createElement(PolyButton, {
                title: "onboarding.screen_04.button.continue",
                onPress: () => {
                    goToNextScreen();
                },}
            )
        )
    );
}

function AppNavigator() {
    const [onboardingShown, setOnboardingShown] = React.useState(null);
    const [languageInitialized, setLanguageInitialized] = React.useState(false);
    const { t, i18n, ready } = useTranslation(null, { useSuspense: false });
    const {
        questionaireInitializationStatus,
        questionnaireList,
        updateStoredQuestionnaires,
    } = React.useContext(QuestionnaireListContext);

    /**
     * Effect to set the language in the app and set the app language in the questionnaire
     */
    React.useEffect(() => {
        const setLanguage = (languageCode) => {
            i18n.changeLanguage(languageCode)
                .then(() => {
                    // In case a questionnaire does not have a language set, use the current one.
                    // This can happe when opening the app, if a user did not answer any question,
                    // as the language is saved when saving answers.
                    questionnaireList.forEach((questionnaire) => {
                        if (questionnaire.question_language === null) {
                            questionnaire.question_language = languageCode;
                        }
                    });
                })
                .then(() => getStoredLanguage())
                .then((savedLanguage) => {
                    // Only change the language in case it needed. This will only happen the first
                    // time when opening the app, as then savedLanguage will be null.
                    if (savedLanguage === null) {
                        return storeLanguage();
                    }
                })
                .finally(() => setLanguageInitialized(true));
        };

        // Only proced if questionnaires where loaded and the translation module is initialized.
        if (questionaireInitializationStatus && ready) {
            const currentLanguageCode = getStoredOrPhoneLanguageCode();
            currentLanguageCode.then((value) => setLanguage(value));
        }
    }, [questionaireInitializationStatus, ready]);

    /**
     * Effect to automatically download the initial questionnaire if no questionnaires are
     * downloaded locally.
     */
    React.useEffect(() => {
        if (
            questionaireInitializationStatus &&
            languageInitialized &&
            questionnaireList.length === 0
        ) {
            updateStoredQuestionnaires().catch((ex) => console.log(ex));
        }
    }, [questionaireInitializationStatus, languageInitialized, questionnaireList]);

    React.useEffect(() => {
        async function getOnboardingShown() {
            let wasShown = await AsyncStorage.getItem("onboardingshown");
            if (wasShown == null) {
                //@ts-ignore
                wasShown = false;
            }
            setOnboardingShown(wasShown);
        }
        getOnboardingShown();
    }, [onboardingShown]);

    // Wait for various parts of the app to read data from storage and initialize.
    if (
        onboardingShown == null ||
        questionaireInitializationStatus === false ||
        ready === false ||
        languageInitialized === false
    ) {
        return React__default.createElement(LoadingScreen, null );
    }
    return (
        React__default.createElement(reactRouterDom.HashRouter, null
            , React__default.createElement(reactRouterDom.Switch, null
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/",}
                    , onboardingShown ? (
                        React__default.createElement(reactRouterDom.Redirect, { to: { pathname: "/home", state: { from: "/" } },} )
                    ) : (
                        React__default.createElement(reactRouterDom.Redirect, { to: { pathname: "/onboarding", state: { from: "/" } },} )
                    )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/onboarding",}
                    , React__default.createElement(OnboardingScreenOne, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/onboarding2",}
                    , React__default.createElement(OnboardingScreenTwo, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/onboarding3",}
                    , React__default.createElement(OnboardingScreenThree, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/onboarding4",}
                    , React__default.createElement(OnboardingScreenFour, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/home",}
                    , React__default.createElement(HomeScreen, null )
                )
                , React__default.createElement(reactRouterDom.Route, { path: "/intro",}
                    , React__default.createElement(IntroNavigator, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/survey",}
                    , React__default.createElement(QuestionScreen, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/survey-completed",}
                    , React__default.createElement(SurveyCompletedScreen, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/survey-legal",}
                    , React__default.createElement(SurveyLegalScreen, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/survey-submitted",}
                    , React__default.createElement(SubmittedScreen, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/survey-error",}
                    , React__default.createElement(AnswersSubmissionErrorScreen, null )
                )
                , React__default.createElement(reactRouterDom.Route, { exact: true, path: "/answers",}
                    , React__default.createElement(AnswersScreen, null )
                )
            )
        )
    );
}

const view = (
    React.createElement(QuestionnaireListProvider, null
        , React.createElement(QuestionnaireProvider, null
            , React.createElement(AppNavigator, null )
        )
    )
);

ReactDOM.render(view, document.getElementById("feature"));

}(React, ReactDOM, uuid, ReactRouterDOM));
